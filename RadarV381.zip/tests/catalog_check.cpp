#include "catalog.hpp"
#include <fstream>
#include <iostream>
using namespace chart_radar;
bool equals(const std::optional<Scores>& actual,const Scores& expected) {
    if(!actual)return false;
    for(auto a:detailOrder)if(displayCents((*actual)[a])!=displayCents(expected[a]))return false;
    return true;
}
Scores readScores(const std::filesystem::path& f) {
    Scores expected{};std::ifstream input(f);
    for(auto a:detailOrder)if(!(input>>expected[a]))throw std::runtime_error("missing fixture scores");
    return expected;
}
// Paired charts keep every input timestamp and lane while changing only reading.
static bool independentMotorAxes() {
    DecodedChart plain{{},{},320.,bms::Layout(7)};
    for(int i=0;i<361;++i) {
        const double t=.1125*i;
        plain.notes.push_back({t,t,i%7,t*2.5});
        if(i%6==1)plain.notes.push_back({t,t,(i+3)%7,t*2.5});
        if(i%9==0)plain.notes.push_back({t,t,7,t*2.5});
    }
    RadarTempo steady;steady.tempos={{0.,150.}};steady.mainVotes[150.]=361;
    const auto sample=[](const DecodedChart& chart,const RadarTempo& tempo,const v38::LampEvidence& evidence) {
        double main=0.;
        auto frames=v37::timeline(chart,tempo,main);
        return v38::splitRating(chart,frames,main,evidence);
    };
    const v38::LampEvidence registered{8,9.,10.,18.,3.,true};
    for(const auto& evidence:{registered,v38::LampEvidence{}}) {
        const auto baseline=sample(plain,steady,evidence);
        for(int pattern=0;pattern<4;++pattern) {
            auto variant=plain;auto tempo=steady;
            if(pattern==0)variant.changes={{8.,.125,0.,false},{17.,8.,0.,false}};
            if(pattern==1)variant.changes={{8.,1.,0.,true},{17.,1.,0.,true}};
            if(pattern==2)variant.changes={{8.,1.,.4,false}};
            if(pattern==3) {
                variant.changes={{8.,.25,0.,false},{17.,4.,0.,false}};
                tempo.tempos={{0.,150.},{8.,37.5},{17.,150.}};
            }
            const auto observed=sample(variant,tempo,evidence);
            if(observed.axes[v37::Reading]<=baseline.axes[v37::Reading])return false;
            for(int a=0;a<v37::Reading;++a)if(observed.axes[a]!=baseline.axes[a])return false;
        }
        auto faster=plain;
        for(auto& n:faster.notes){n.start*=.7;n.end*=.7;}
        if(sample(faster,steady,evidence).axes[v37::Burst]==baseline.axes[v37::Burst])return false;
    }
    return true;
}

int main(int argc,char** argv) {
    if(argc!=4)return 2;
    if(!independentMotorAxes())return 23;
    namespace fs=std::filesystem;
    const fs::path assets=argv[1],tests=argv[2],scratch=argv[3];
    fs::create_directories(scratch);
    ChartCatalog bundled((assets/"charts.tsv").string());
    std::unordered_map<std::string,int> grades;
    std::ifstream metadata(assets/"tiers-v38.tsv");std::string md5,signature;int tier;
    std::string entry;
    while(std::getline(metadata,entry)){std::istringstream row(entry);if(row>>md5>>signature>>tier)grades.emplace(md5,tier);}
    std::unordered_map<std::string,double> walkure;
    std::ifstream labels(tests/"walkure-test-only.tsv");double hard;
    while(labels>>md5>>hard)walkure.emplace(md5,hard);
    if(walkure.size()!=1028)return 20;
    if(grades.size()!=1028)return 3;
    std::ifstream table(assets/"charts-v381.tsv");std::string line;int count=0,excluded=0;
    std::array<int,24> eligible{},inside{},hardHits{},both{};
    while(std::getline(table,line)){
        std::istringstream row(line);row>>md5;Scores points{};
        for(auto a:detailOrder)if(!(row>>points[a]))return 4;
        if(!equals(bundled.find(md5),points))return 5;
        ++count;auto grade=grades.find(md5);if(grade==grades.end())continue;
        auto traits=bundled.traits(md5,7);if(!traits)return 6;
        if(displayedShortfall(traits->recoveryShortfall)==100){++excluded;continue;}
        const int i=grade->second-1;if(i<0||i>=24)return 7;
        const double center=v38::parameters::anchors[i];++eligible[i];
        const auto peak=*std::max_element(points.begin(),points.end());
        const bool inBand=peak>=center-50. && peak<=center+50.;
        auto estimate=bundled.hardEstimate(md5);
        if(!estimate)return 21;
        const bool matched=std::abs(std::llround(*estimate*100.)-std::llround(walkure.at(md5)*100.))<=100;
        inside[i]+=inBand;hardHits[i]+=matched;both[i]+=matched && inBand;
    }
    if(count!=1954 || excluded!=22)return 8;
    for(int i=0;i<24;++i){
        std::cout<<"grade "<<i+1<<": "<<inside[i]<<", "<<hardHits[i]<<", "<<both[i]<<"/"<<eligible[i]<<"\n";
        if(eligible[i]==0||10*both[i]<9*eligible[i])return 9;
    }
    std::string fixtureHash;std::ifstream(tests/"fixture.hash")>>fixtureHash;
    const auto plain=readScores(tests/"reference.txt"),graded=readScores(tests/"grade-reference.txt");
    if(equals(plain,graded))return 10;
    double fixtureHard;std::ifstream(tests/"grade-hard.txt")>>fixtureHard;
    const auto source=(tests/"fixture.bms").string();
    const std::string twin="11111111111111111111111111111111";
    {
        ChartCatalog unknown((scratch/"absent.tsv").string());
        if(!equals(unknown.resolve(fixtureHash,source,7,true),plain))return 11;
    }
    fs::copy_file(tests/"fixture-grade.tsv",scratch/"tiers-v38.tsv",fs::copy_options::overwrite_existing);
    for(int i=0;i<2;++i){
        ChartCatalog dyn((scratch/"absent.tsv").string(),(scratch/"cache.sqlite").string());
        if(!equals(i?dyn.find(fixtureHash):dyn.resolve(fixtureHash,source,7,true),graded))return 12;
        if(!equals(i?dyn.find(twin):dyn.resolve(twin,source,7,true),graded))return 13;
        if(dyn.hardEstimate(twin)!=std::optional<double>(fixtureHard) || dyn.hardEstimate(fixtureHash)!=dyn.hardEstimate(twin))return 22;
    }
    std::cout<<"1954 profiles; 24 grade gates; exact and equivalent charts; fresh/warm cache passed.\n";
}

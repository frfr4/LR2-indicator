const fs = require('node:fs');
const { createCanvas, loadImage } = require('@napi-rs/canvas');
const glyphs=require('./glyphs.json');
const COLORS={label:[217,223,230],yes:[255,177,76],no:[195,204,216]};
const surface=createCanvas;
function makeMask(glyph,color){
 const [w,h,b64]=glyph,src=atob(b64), c=surface(w,h),ctx=c.getContext('2d'), data=ctx.createImageData(w,h);
 for(let i=0;i<w*h;i++){data.data.set(color,i*4);data.data[i*4+3]=src.charCodeAt(i);}
 ctx.putImageData(data,0,0);return c;
}
function inkName(ctx,str,x,maxWidth,scale){
 const glyphRun=surface(112,14),run=glyphRun.getContext('2d');let pen=0;
 for(const ch of str){if(ch===' '){pen+=5;continue}
  const glyph=makeMask(glyphs.labels[ch],COLORS.label);run.drawImage(glyph,pen,0);pen+=glyph.width-1;
 }
 const w=pen+1;ctx.drawImage(glyphRun,0,0,w,14,x,12.5+(6-12.5)*scale,Math.min(maxWidth,w)*scale,14*scale);
}
function valueText(str,color,strength){
 const slots=[...str].map(ch=>Math.max(glyphs.values[ch][0],/[0-9]/.test(ch)?12:0));
 const total=slots.reduce((acc,v)=>acc+v,0);
 const glyphRun=surface(total+4,21),run=glyphRun.getContext('2d');let pen=2;
 for(const [index,ch] of [...str].entries()){
  const gm=makeMask(glyphs.values[ch],color);
  run.drawImage(gm,pen+Math.floor((slots[index]-gm.width)/2),Math.floor((21-gm.height)/2));pen+=slots[index];
 }
 if(strength<=0)return {glyphRun,total};
 const out=surface(glyphRun.width+6,25),c=out.getContext('2d');
 const rim=surface(glyphRun.width,21),rr=rim.getContext('2d');rr.drawImage(glyphRun,0,0);rr.globalCompositeOperation='source-in';rr.fillStyle='white';rr.fillRect(0,0,rim.width,21);
 c.shadowOffsetX=.5;c.shadowOffsetY=.75;c.shadowBlur=1.5;c.shadowColor='rgba(255,255,255,'+strength+')';
 c.globalAlpha=.7*strength;for(const [x,y] of [[-.6,0],[.6,0],[0,-.6],[0,.6]])c.drawImage(rim,3+x,2+y);
 c.shadowColor='transparent';c.globalAlpha=1;c.drawImage(glyphRun,3,2);c.globalAlpha=strength*.8;c.drawImage(glyphRun,3.6,2);
 return {glyphRun:out,total,pad:3};
}
function uiValue(ctx,text,color,position,align,scale,amount=0){
 const out=valueText(text,color,amount), x=align==='middle'?Math.round(position-out.total/2):position-out.total;
 const left=x-2-(out.pad||0),top=out.pad?0:2;
 ctx.drawImage(out.glyphRun,position+(left-position)*scale,12.5+(top-12.5)*scale,out.glyphRun.width*scale,out.glyphRun.height*scale);
}
const height = 24, width = 274;
function canvas(w=width,h=height) { return createCanvas(w,h); }
function color(pct) { return [255, Math.round(194-155*pct/100), Math.round(111-55*pct/100)]; }
function value(ctx,pct) {
  if (!pct) uiValue(ctx,'-',[195,204,216],258,'right',.8);
  else uiValue(ctx,pct+'%',color(pct),264,'right',.8,Math.pow(Math.max(0,(pct-50)/50),.65));
}
function end(ctx,yes) { uiValue(ctx,yes?'Y':'N',yes?[255,177,76]:[195,204,216],110,'middle',.8); }
function plate(ctx,traits) {
  ctx.drawImage(traits,0,0,width,height,0,0,width,height);
  for(const [x,w] of [[7,89],[134,72]]){ctx.clearRect(x,4,w,16);ctx.drawImage(traits,85,4,1,16,x,4,w,16);}
  inkName(ctx,'END SPIKE',9,90,.8);inkName(ctx,'LOW REC.',137,68,.8);
}
function checkBounds(ctx,low,high,tag) {
  const rgba=ctx.getImageData(0,0,width,height).data;
  for (let j=0;j<height;j++) for(let i=0;i<width;i++){
    if ((i<low||i>=high) && rgba[(j*width+i)*4+3])throw Error([tag,'out of bounds at',i,j,rgba[(j*width+i)*4+3]]);
  }
}
(async()=>{
  const oldTraits=await loadImage(process.argv[2]);
  const traits=canvas(274,648),tc=traits.getContext('2d');
  plate(tc,oldTraits);
  for (const [index,yes] of [[0,true],[1,false]]) {
    const layer=canvas(),lc=layer.getContext('2d');end(lc,yes);checkBounds(lc,102,118,'end');
    tc.drawImage(layer,102,0,16,24,index*16,24,16,24);
  }
  for(let pct=0;pct<=100;pct++){
    const layer=canvas(),lc=layer.getContext('2d');value(lc,pct);
    if(!pct){checkBounds(lc,247,263,0);tc.drawImage(layer,247,0,16,24,32,24,16,24);}
    else {const i=pct-1;checkBounds(lc,208,272,pct);tc.drawImage(layer,208,0,64,24,64*(i%4),48+24*Math.floor(i/4),64,24);}
  }
  fs.writeFileSync(process.argv[3],traits.toBuffer('image/png'));
})().catch(err=>{console.error(err);process.exitCode=1;});

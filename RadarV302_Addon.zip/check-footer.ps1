param([string]$Backend, [string]$Frames)
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Drawing
foreach ($score in @(0, 40, 50, 52, 74, 75, 76, 100)) {
  $actual = [Drawing.Bitmap]::new((Join-Path $Frames "$Backend-footer-$score.png"))
  $expected = [Drawing.Bitmap]::new((Join-Path $PSScriptRoot "expected/$score.png"))
  try {
    if ($actual.Width -ne 274 -or $actual.Height -ne 24) { throw 'Incorrect footer size' }
    $maximum = 0
    $sum = 0
    for ($y = 0; $y -lt 24; $y++) {
      for ($x = 0; $x -lt 274; $x++) {
        $a = $actual.GetPixel($x, $y)
        $b = $expected.GetPixel($x, $y)
        $diff = [Math]::Max([Math]::Abs([int]$a.R-$b.R), [Math]::Max([Math]::Abs([int]$a.G-$b.G), [Math]::Abs([int]$a.B-$b.B)))
        $maximum = [Math]::Max($maximum, $diff)
        $sum += $diff
      }
    }
    $mean = $sum / (274*24)
    Write-Host "$Backend footer $score | maximum channel difference $maximum, average $mean"
    if ($maximum -gt 12 -or $mean -gt 2) { throw "Footer differs from the approved design at $score" }
  } finally {
    $actual.Dispose()
    $expected.Dispose()
  }
}

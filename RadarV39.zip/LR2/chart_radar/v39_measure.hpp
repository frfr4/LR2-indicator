#pragma once
#include "v38_scores.hpp"

namespace chart_radar::v39 {
struct Evidence {
    v37::Eight raw{};
    double duration=0., keyHeads=0., direct90=0.,direct150=0., fatigueRms=0.;
};
inline double weightedTail(const std::array<double,v37::windows>& values,double power) {
    double sum=0.;
    for(double x:values)sum+=std::pow(x,power);
    return std::pow(sum/values.size(),1./power);
}
inline Evidence measure(const DecodedChart& chart,const RadarTempo& tempo) {
    Evidence measured;
    double main=0.;
    const auto fullRows=v37::timeline(chart,tempo,main);
    if(fullRows.size()<2 || main<=0.)return measured;
    const auto scroll=v37::measureFrames(chart,fullRows,main);
    measured.raw[v37::Reading]=v37::dose(scroll.summary[0][v37::Reading]);
    measured.raw[v37::Deck]=v37::dose(scroll.summary[0][v37::Deck]);
    std::vector<v37::Frame> keys;
    for(auto row:fullRows)if(row.keys) {
        row.scratch=false;row.read=0.;row.beat=60./main;keys.push_back(row);
    }
    if(keys.size()<2)return measured;
    const double origin=keys.front().t;
    for(auto& row:keys)row.t-=origin;
    const double duration=keys.back().t;
    if(duration<=0.)return measured;
    measured.duration=duration;
    const auto keyData=v37::measureFrames(chart,keys,main);
    for(int a:{v37::Burst,v37::Delay,v37::Chords})measured.raw[a]=v37::dose(keyData.summary[0][a]);
    const auto windows=v37::intervals(keys,duration);
    using Costs=std::array<double,3>;
    std::vector<Costs> prefix(keys.size()+1);
    std::array<int,7> previous;previous.fill(-1);
    std::array<double,7> chain{};
    unsigned prevMask=0;
    for(size_t i=0;i<keys.size();++i) {
        const auto& row=keys[i];
        const unsigned mask=row.keys;
        const int width=v37::pop(mask);
        double jack=0.,repeatedEffort=0.;
        for(int lane=0;lane<7;++lane)if(mask&(1u<<lane)) {
            const int last=previous[lane];
            if(last>=0) {
                const double dt=std::max(.001,row.t-keys[last].t);
                const auto separation=i-last;
                const double direct=1./(double(separation)*separation);
                const double fast=1./(1.+std::pow(dt/.155,4));
                chain[lane]=fast*(1.+direct*chain[lane]);
                const double speed=std::min(24.,1./dt)/8.;
                jack+=fast*speed*speed*(.09+.91*direct)*(1.+.20*std::log1p(chain[lane]));
                repeatedEffort+=fast;
                measured.direct90+=separation==1 && dt<=.09;
                measured.direct150+=separation==1 && dt<=.15;
            }
            previous[lane]=int(i);
        }
        measured.keyHeads+=width;
        const double stream=.58*width+.42*v37::pop(mask&~prevMask);
        const double effort=width+.14*std::pow(double(width-1),1.5)+.35*repeatedEffort;
        prefix[i+1]={prefix[i][0]+stream,prefix[i][1]+jack,prefix[i][2]+effort};
        prevMask=mask;
    }
    std::array<double,v37::windows> notes{},jacks{},endurance{};
    for(int j=0;j<v37::windows;++j) {
        auto rate=[&](int window,int cost) {
            const auto [lo,hi]=windows.slots[window][j];
            return (prefix[hi][cost]-prefix[lo][cost])/(duration*v37::widths[window]);
        };
        notes[j]=std::sqrt(rate(1,0)*rate(2,0));
        jacks[j]=std::pow(rate(0,1)*rate(0,1)*rate(1,1),1./3.);
        endurance[j]=std::sqrt(rate(2,2)*rate(3,2));
    }
    measured.raw[v37::Notes]=weightedTail(notes,3.);
    measured.raw[v37::Repeat]=weightedTail(jacks,6.);
    measured.fatigueRms=weightedTail(endurance,1.65);
    measured.raw[v37::Endurance]=measured.fatigueRms*std::pow(duration/120.,.35);
    return measured;
}
}

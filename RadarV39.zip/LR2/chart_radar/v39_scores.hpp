#pragma once
#include "v39_measure.hpp"
#include "v39_parameters.hpp"
#include <optional>

namespace chart_radar::v39 {
struct Lamp {
    int star=0,oj=-1;
    double easy=0.,normal=0.,fc=-1.,dis=1.;
    bool operator==(const Lamp& x) const {
        return star==x.star&&oj==x.oj&&easy==x.easy&&normal==x.normal&&fc==x.fc&&dis==x.dis;
    }
};
class Grades {
    std::unordered_map<std::string,Lamp> byFile;
    std::unordered_map<std::string,std::optional<Lamp>> aliases;
public:
    void load(const std::filesystem::path& file) {
        std::ifstream input(file);std::string hash,sig;Lamp lamp;
        while(input>>hash>>sig>>lamp.star>>lamp.oj>>lamp.easy>>lamp.normal>>lamp.fc>>lamp.dis) {
            if(hash.size()!=32||sig.size()!=48||lamp.star<0||lamp.star>24||lamp.oj< -1||lamp.oj>6||lamp.dis<=0.)continue;
            byFile.emplace(hash,lamp);
            auto [it,inserted]=aliases.emplace(sig,lamp);
            if(!inserted && it->second && !(*it->second==lamp))it->second.reset();
        }
    }
    std::optional<Lamp> find(const std::string& hash,const DecodedChart& c,const RadarTempo& t,double main) const {
        auto it=byFile.find(hash);if(it!=byFile.end())return it->second;
        if(aliases.empty())return {};
        auto alias=aliases.find(v38::gradeSignature(c,t,main));
        return alias==aliases.end()?std::optional<Lamp>{}:alias->second;
    }
};
constexpr std::array<int,7> hardAxes{v37::Notes,v37::Burst,v37::Delay,v37::Repeat,v37::Chords,v37::Deck,v37::Reading};
using Features=std::array<double,21>;
inline Features features(const Lamp& e,const Evidence& measured,double total,int count) {
    const double n=e.normal,gap=std::max(0.,n-e.easy),dis=std::max(.1,e.dis);
    Features x{1.,n/20.,gap,std::log1p(gap),1./dis,std::log(dis),gap/(1.+dis),
        e.fc<0?5.:e.fc-n,e.fc<0?1.:0.,std::max(0.,n-21.)/3.,double(e.star),double(e.oj),
        std::log1p(total),std::log1p(double(count))};
    for(size_t i=0;i<hardAxes.size();++i)x[14+i]=std::log1p(measured.raw[hardAxes[i]]);
    return x;
}
inline double lampEstimate(const Lamp& e,const Features& x) {
    const double linear=std::inner_product(std::begin(parameters::lamp),std::end(parameters::lamp),x.begin(),0.);
    double gap=std::max(0.,std::sinh(std::clamp(linear,-4.,4.)));
    if(e.fc>=0.) {
        const double room=std::max(0.,e.fc-e.normal);
        gap=gap*room/std::max(1.e-8,room+gap);
    }
    return e.normal+gap;
}
inline double hardEstimate(const Lamp& e,const Features& x,double base) {
    double residual=parameters::bias;
    for(int idx:parameters::trees) {
        while(parameters::nodes[idx].field>=0) {
            const auto& n=parameters::nodes[idx];
            idx=x[n.field]<=n.cut?n.left:n.right;
        }
        residual+=parameters::nodes[idx].value;
    }
    const double hard=std::max(e.normal,base+residual);
    return e.fc>=0.?std::min(e.fc,hard):hard;
}
inline double absoluteScore(int axis,double value) {
    if(axis==v37::Endurance)return 20.*value;
    constexpr double marks[]{150.,355.,515.,655.,750.};
    const auto& q=parameters::doses;
    double lo=0.,base=0.;
    for(int i=0;i<5;++i) {
        const double hi=q[i][axis];
        if(value<=hi)return base+(marks[i]-base)*(value-lo)/(hi-lo);
        lo=hi;base=marks[i];
    }
    const double slope=(marks[4]-marks[2])/(q[4][axis]-q[2][axis]);
    return 750.+450.*std::log1p((value-lo)*slope/450.);
}
struct Scale {double anchor,pivot;};
inline Scale scale(const Lamp& evidence,double base) {
    double anchor=v37::ruler(base),pivot=.76;
    if(evidence.star>0) {
        const int i=evidence.star-1;const double center=v38::parameters::anchors[i];
        pivot=parameters::pivot[i];
        if(evidence.oj>=0) {
            anchor=std::clamp(anchor,center-23.,center+23.);pivot=std::min(pivot,.76);
        } else anchor=center+22.*std::tanh((anchor-center)/55.);
    }
    return {std::max(60.,anchor),pivot};
}
inline double axisScore(int axis,double load,const std::optional<Scale>& ruler) {
    const double x=absoluteScore(axis,load);
    if(axis==v37::Endurance||!ruler)return x;
    const double shoulder=ruler->anchor*ruler->pivot;
    return x<shoulder ? (ruler->anchor-24.)*std::pow(x/shoulder,1.65) :
        ruler->anchor-24.+11.*std::log1p((x-shoulder)/110.);
}
inline double fallbackHard(double peak) {
    if(peak<=0.)return 0.;
    if(peak<100.)return std::max(0.,3.+3.*std::log(peak/100.));
    if(peak<=200.)return 3.+(peak-100.)/50.;
    if(peak<=700.)return 5.+(peak-200.)*18./500.;
    return 23.+(peak-700.)/50.;
}
inline Scores catalogScores(const DecodedChart& chart,const RadarTempo& timing,const std::string& hash,const Grades& grades,double& hard) {
    auto m=measure(chart,timing);double main=0.;
    // Grade matching uses the same MAIN BPM tie breaker as the native timeline.
    int votes=-1;
    for(const auto& entry:timing.mainVotes)if(entry.second>votes||(entry.second==votes&&entry.first>main)){votes=entry.second;main=entry.first;}
    if(main<=0.&&!timing.tempos.empty())main=timing.tempos.front().second;
    auto e=grades.find(hash,chart,timing,main);std::optional<Scale> ruler;
    if(e) {
        const int count=gaugeNoteCount(chart);const double total=chart.total>0.?chart.total:defaultGaugeTotal(count);
        const auto x=features(*e,m,total,count);const auto base=lampEstimate(*e,x);
        ruler=scale(*e,base);hard=hardEstimate(*e,x,base);
    }
    constexpr Axis slots[]{Density,Peak,Stair,Jack,Chord,Stamina,Scratch,Soflan};
    Scores result{};double top=0.;
    for(int i=0;i<v37::Skills;++i) {
        const double value=std::round(100.*axisScore(i,m.raw[i],ruler))/100.;
        result[slots[i]]=value;
        if(i!=v37::Endurance)top=std::max(top,value);
    }
    if(!e)hard=fallbackHard(top);
    hard=std::round(100.*hard)/100.;return result;
}
}

param([Parameter(Mandatory=$true)][string]$Game)
$ErrorActionPreference='Stop'
try {
    $Game=(Resolve-Path -LiteralPath $Game).Path
    $config=Join-Path $Game 'LR2files\Config\config.xml'
    if (!(Test-Path -LiteralPath $config -PathType Leaf)) { throw 'Cannot find LR2files\Config\config.xml. Run the game once, close it, then run this file beside the game executable.' }
    $paths=[ordered]@{
        select='LR2files\Theme\KCOOL_WMIX_FHD\WMIX\select\select_radar.lr2skin'
        decide='LR2files\Theme\KCOOL_WMIX_FHD\Decide\decide.lr2skin'
        result='LR2files\Theme\KCOOL_WMIX_FHD\WMIX\result\WMIX_RESULT.lr2skin'
        skinselect='LR2files\Theme\KCOOL_WMIX_FHD\Menu\Menu.lr2skin'
        keyconfig='LR2files\Theme\KCOOL_WMIX_FHD\KeyConfig\setup.lr2skin'
    }
    function Update-Scenes($config, $paths) {
    foreach ($file in $paths.Values) {
        if (!(Test-Path -LiteralPath (Join-Path $Game $file) -PathType Leaf)) {throw "Missing skin: $file. Extract the full skin ZIP first."}
    }
    $bytes=[IO.File]::ReadAllBytes($config)
    # Latin-1 is used as a reversible byte mapping for ASCII-compatible encodings.
    $enc=[Text.Encoding]::GetEncoding(28591)
    if ($bytes.Length -ge 2) {
        if ($bytes[0] -eq 255 -and $bytes[1] -eq 254) {$enc=[Text.Encoding]::Unicode}
        if ($bytes[0] -eq 254 -and $bytes[1] -eq 255) {$enc=[Text.Encoding]::BigEndianUnicode}
    }
    $text=$enc.GetString($bytes)
    $sections=[regex]::Matches($text,'(?is)<skin\s*>.*?</skin\s*>')
    if ($sections.Count -ne 1) {throw 'Cannot identify the skin settings in config.xml.'}
    $match=$sections[0]
    $section=$match.Value
    foreach ($tag in $paths.Keys) {
        $pattern=[regex]"(?is)<$tag\s*(?:/>|>.*?</$tag\s*>)"
        if ($pattern.Matches($section).Count -gt 1) {throw "Duplicate setting: $tag"}
        $entry="<$tag>$($paths[$tag])</$tag>"
        if ($pattern.IsMatch($section)) {$section=$pattern.Replace($section,$entry,1)}
        else {$section=$section.Insert($section.LastIndexOf('</'),$entry)}
    }
    if ($section -ceq $match.Value) { Write-Host 'Already applied.'; return }
    $result=$text.Remove($match.Index,$match.Length).Insert($match.Index,$section)
    $tmp="$config.$([guid]::NewGuid()).tmp"
    $backup="$config.$([guid]::NewGuid()).bak"
    try {
        [IO.File]::WriteAllBytes($tmp,$enc.GetBytes($result))
        if ([Convert]::ToBase64String([IO.File]::ReadAllBytes($config)) -cne [Convert]::ToBase64String($bytes)) {throw 'Settings changed during the update. Close the game and retry.'}
        [IO.File]::Replace($tmp,$config,$backup)
    } finally {if ([IO.File]::Exists($tmp)) {[IO.File]::Delete($tmp)}}
    Write-Host "Applied. Backup: $backup"
    }
    Update-Scenes $config $paths
    $extended=Join-Path $Game 'LR2files\Config\openlr2-config.xml'
    if (Test-Path -LiteralPath $extended -PathType Leaf) {
        Update-Scenes $extended @{courseresult='LR2files\Theme\KCOOL_WMIX_FHD\WMIX\courseresult\courseresult.lr2skin'}
    }
    exit 0
} catch { Write-Host "Failed: $($_.Exception.Message)"; exit 1 }

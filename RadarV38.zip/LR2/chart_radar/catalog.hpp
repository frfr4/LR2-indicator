#pragma once
#include "player_db.hpp"
#include "physical_id.hpp"
#include "v38_scores.hpp"
#include <atomic>
#include <mutex>
#include <optional>
#include <sstream>

namespace chart_radar {
using Database=std::unique_ptr<sqlite3,decltype(&sqlite3_close)>;
inline Database readOnly(const std::string& path) {
    sqlite3* ptr=nullptr;
    const int status=sqlite3_open_v2(path.c_str(),&ptr,SQLITE_OPEN_READONLY,nullptr);
    Database db(ptr,sqlite3_close);
    if (status!=SQLITE_OK) throw std::runtime_error("could not open score or song database");
    sqlite3_busy_timeout(db.get(),1200);
    return db;
}
class ChartCatalog {
    mutable std::mutex mutex;
    struct Entry { Scores scores; ChartTraits traits; std::optional<double> hard{}; };
    using Entries = std::unordered_map<std::string,Entry>;
    Entries entries, baseline;
    v38::Grades grades;
    using PoorMap = std::unordered_map<std::string,int>;
    PoorMap poor;
    std::unordered_map<std::string,std::string> physicalIndex;
    Database cache{nullptr,sqlite3_close};
    static std::string key(const std::string& hash,int mode) {
        return mode==7 ? hash : hash+"#"+std::to_string(mode);
    }
    void openCache(const std::string& path) {
        sqlite3* ptr=nullptr;
        int status=sqlite3_open_v2(path.c_str(),&ptr,SQLITE_OPEN_READWRITE|SQLITE_OPEN_CREATE,nullptr);
        cache.reset(ptr);
        if (status!=SQLITE_OK) {cache.reset();return;}
        sqlite3_busy_timeout(ptr,350);
        sqlite3_exec(ptr,"PRAGMA journal_mode=WAL; PRAGMA synchronous=NORMAL",nullptr,nullptr,nullptr);
        if (sqlite3_exec(ptr,"CREATE TABLE IF NOT EXISTS radar_v38_chart (hash TEXT,mode INTEGER,"
                "a INTEGER,b INTEGER,c INTEGER,d INTEGER,e INTEGER,f INTEGER,g INTEGER,h INTEGER,"
                "end_spike INTEGER,shortfall INTEGER,hard REAL,PRIMARY KEY(hash,mode))",nullptr,nullptr,nullptr)!=SQLITE_OK) {cache.reset();return;}
        readCache(ptr,"SELECT * FROM radar_v38_chart",entries);
        if (sqlite3_exec(ptr,"CREATE TABLE IF NOT EXISTS radar_hard_poor_v1 "
                "(hash TEXT,mode INTEGER,cents INTEGER,PRIMARY KEY(hash,mode))",nullptr,nullptr,nullptr)==SQLITE_OK) {
            auto q=query(ptr,"SELECT hash,mode,cents FROM radar_hard_poor_v1");
            while (sqlite3_step(q.get())==SQLITE_ROW) {
                auto hash=reinterpret_cast<const char*>(sqlite3_column_text(q.get(),0));
                const int cents=sqlite3_column_int(q.get(),2);
                if (hash && sqlite3_column_bytes(q.get(),0)==32 && sqlite3_column_type(q.get(),2)==SQLITE_INTEGER && cents>=0 && cents<=9000)
                    poor.emplace(key(hash,sqlite3_column_int(q.get(),1)),cents);
            }
        }
        // Only 7-key scores ever included the external calculator. Recover other key modes.
        for (const auto table : {"radar_v37_chart","radar_v36_chart","radar_v35_chord","radar_v34_phrase","radar_v33_native","radar_v28_range","radar_v27_mina527"}) {
            auto exists=query(ptr,"SELECT 1 FROM sqlite_master WHERE type='table' AND name=?1");
            sqlite3_bind_text(exists.get(),1,table,-1,SQLITE_STATIC);
            if (sqlite3_step(exists.get())==SQLITE_ROW) {
                const auto sql=std::string("SELECT * FROM ")+table+" WHERE mode<>7";
                readCache(ptr,sql.c_str(),entries);
            }
        }
        auto oldTable=query(ptr,"SELECT 1 FROM sqlite_master WHERE type='table' AND name='radar_v26'");
        if (sqlite3_step(oldTable.get())==SQLITE_ROW)
            readCache(ptr,"SELECT * FROM radar_v26",baseline);
    }
    static void readCache(sqlite3* ptr,const char* sql,Entries& dest) {
        auto rows=query(ptr,sql);
        while (sqlite3_step(rows.get())==SQLITE_ROW) {
            const auto* h=sqlite3_column_text(rows.get(),0);
            if (!h || sqlite3_column_bytes(rows.get(),0)!=32) continue;
            Scores v{};
            bool valid=true;
            for (int i=0;i<Count;++i) {
                const auto cents=sqlite3_column_int64(rows.get(),2+i);
                valid &= sqlite3_column_type(rows.get(),2+i)==SQLITE_INTEGER && cents>=0;
                v[i]=cents/100.;
            }
            const int late=sqlite3_column_int(rows.get(),10),shortfall=sqlite3_column_int(rows.get(),11);
            std::optional<double> hard;
            if(sqlite3_column_count(rows.get())>12 && sqlite3_column_int(rows.get(),1)==7 &&
               sqlite3_column_type(rows.get(),12)==SQLITE_FLOAT)hard=sqlite3_column_double(rows.get(),12);
            if (valid && sqlite3_column_type(rows.get(),10)==SQLITE_INTEGER &&
                sqlite3_column_type(rows.get(),11)==SQLITE_INTEGER && (late==0 || late==1) && shortfall>=0 && shortfall<=100)
                dest.emplace(key(reinterpret_cast<const char*>(h),sqlite3_column_int(rows.get(),1)),
                                Entry{v,{late!=0,shortfall},hard});
        }
    }
    static void readTable(const std::filesystem::path& file,Entries& dest,PoorMap* losses=nullptr) {
        std::ifstream f(file);
        std::string line;
        while (std::getline(f,line)) {
            std::istringstream in(line);
            std::string hash; in>>hash;
            Scores values{};
            for (Axis a : detailOrder) in>>values[a];
            int late=-1,shortfall=-1;
            in>>late>>shortfall;
            if (in && (late==0 || late==1) && shortfall>=0 && shortfall<=100 && hash.size()==32 && std::all_of(values.begin(),values.end(),[](double v){return std::isfinite(v) && v>=0.;})) {
                auto id=hashKey(hash);
                Entry entry{values,{late!=0,shortfall}};
                int cents;double hard;
                if (losses && in>>cents && cents>=0 && cents<=9000) {
                    losses->emplace(id,cents);
                    if(in>>hard && std::isfinite(hard))entry.hard=hard;
                }
                dest.emplace(id,entry);
            }
        }
    }
    static std::optional<Entry> lookup(const Entries& source,const std::string& hash,int mode) {
        const auto it=source.find(key(hash,mode));
        if (it==source.end()) return {};
        return it->second;
    }
    std::optional<Entry> finalEntry(const std::string& hash,int mode) const {
        std::lock_guard<std::mutex> lock(mutex);
        return lookup(entries,hash,mode);
    }
public:
    explicit ChartCatalog(const std::string& file,const std::string& cachePath={}) {
        const auto path=std::filesystem::u8path(file);
        readTable(path,baseline);
        readTable(path.parent_path()/"charts-v38.tsv",entries,&poor);
        grades.load(path.parent_path()/"tiers-v38.tsv");
        std::ifstream ids(path.parent_path()/"physical-v26.tsv");
        std::string id,hash;
        while (ids>>id>>hash) physicalIndex.emplace(id,hash);
        if (!cachePath.empty()) {
            try {openCache(cachePath);} catch(const std::exception&) {cache.reset();}
        }
    }
    std::optional<Scores> find(const std::string& hash,int mode=7) const {
        if (auto entry=finalEntry(hash,mode)) return entry->scores;
        return {};
    }
    std::optional<double> hardEstimate(const std::string& hash,int mode=7) const {
        if(auto entry=finalEntry(hash,mode))return entry->hard;
        return {};
    }
    std::optional<Scores> fallback(const std::string& hash,int mode=7) const {
        if (mode==7) return find(hash,mode);
        if (auto ref=lookup(baseline,hash,mode)) return ref->scores;
        return {};
    }
    std::optional<ChartTraits> traits(const std::string& hash,int mode) const {
        if (auto entry=finalEntry(hash,mode)) return entry->traits;
        if (mode==7) return {};
        if (auto ref=lookup(baseline,hash,mode)) return ref->traits;
        return {};
    }
    std::optional<int> poorExtra(const std::string& hash,int mode) const {
        std::lock_guard<std::mutex> lock(mutex);
        const auto it=poor.find(key(hash,mode));
        if (it==poor.end()) return {};
        return it->second;
    }
    std::optional<Scores> resolve(const std::string& hash,const std::string& file,int mode=7,bool needPoor=false) {
        const auto existing=find(hash,mode);
        if (existing && (!needPoor || poorExtra(hash,mode).has_value())) return existing;
        if (file.empty()) return {};
        try {
            auto path=std::filesystem::u8path(file);
            if (!std::filesystem::exists(path)) path=std::filesystem::path(file);
            const unsigned seed=static_cast<unsigned>(std::stoul(hash.substr(0,8),nullptr,16));
            RadarTempo timing;
            auto decoded=decodeChart(path,mode,seed,mode==7 ? &timing : nullptr);
            const int extra=extraPoorCents(gaugeNoteCount(decoded),static_cast<int>(decoded.total));
            {
                std::lock_guard<std::mutex> lock(mutex);
                if (poor.emplace(key(hash,mode),extra).second && cache) {
                    try {
                        auto put=query(cache.get(),"INSERT OR REPLACE INTO radar_hard_poor_v1 (hash,mode,cents) VALUES(?,?,?)");
                        sqlite3_bind_text(put.get(),1,hash.c_str(),-1,SQLITE_TRANSIENT);
                        sqlite3_bind_int(put.get(),2,mode);
                        sqlite3_bind_int(put.get(),3,extra);
                        sqlite3_step(put.get());
                    } catch(const std::exception&) { /* Keep the selection-time value in memory. */ }
                }
            }
            if (existing) return existing;
            Entry result{};
            if(mode==7) {
                double hard;
                result.scores=v38::catalogScores(decoded,timing,hash,grades,hard);
                result.hard=hard;
                // Preserve the game's existing LOW.REC / END SPIKE indicators.
                auto match=physicalIndex.find(physicalId(decoded));
                auto known=match==physicalIndex.end() ? std::optional<Entry>{} : finalEntry(match->second,7);
                if(known) result.traits=known->traits;
                else if(auto ref=lookup(baseline,hash,7)) result.traits=ref->traits;
                else result.traits=assessPassages(decoded.notes,7,decoded.total).traits;
            } else if(auto ref=lookup(baseline,hash,mode)) {
                result=*ref;
            } else {
                const auto& layout=decoded.layout;
                auto measured=analyze(std::move(decoded.notes),decoded.changes,layout.perSide,layout.sides,layout.scratches,decoded.total);
                result={measured.scores,measured.passage.traits};
            }
            for (auto& score:result.scores) score=displayCents(score)/100.;
            const auto& value=result.scores;
            const auto& traits=result.traits;
            std::lock_guard<std::mutex> lock(mutex);
            if (entries.emplace(key(hash,mode),result).second && cache) {
                try {
                    auto put=query(cache.get(),"INSERT OR REPLACE INTO radar_v38_chart VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)");
                    sqlite3_bind_text(put.get(),1,hash.c_str(),-1,SQLITE_TRANSIENT);
                    sqlite3_bind_int(put.get(),2,mode);
                    for (int i=0;i<Count;++i) sqlite3_bind_int64(put.get(),3+i,displayCents(value[i]));
                    sqlite3_bind_int(put.get(),11,traits.endSpike?1:0);
                    sqlite3_bind_int(put.get(),12,traits.recoveryShortfall);
                    if(result.hard)sqlite3_bind_double(put.get(),13,*result.hard);
                    sqlite3_step(put.get());
                } catch(const std::exception&) { /* The in-memory result remains available. */ }
            }
            return value;
        } catch(const std::exception&) { return {}; }
    }
};
inline PlayerRating loadProfile(const std::string& profilePath,const std::string& songsPath,ChartCatalog& catalog,
                                const std::atomic<bool>* cancel=nullptr) {
    auto profile=readOnly(profilePath);
    auto songs=readOnly(songsPath);
    auto paths=query(songs.get(),"SELECT path,mode FROM song WHERE hash IN (?1,upper(?1))");
    std::optional<Scores> chart;
    return readPlayer(profile.get(),[&](const std::string& hash)->const Scores* {
        if (cancel && cancel->load()) throw std::runtime_error("selection closed");
        chart=catalog.find(hash);
        if (!chart) {
            sqlite3_reset(paths.get());
            sqlite3_bind_text(paths.get(),1,hash.c_str(),-1,SQLITE_TRANSIENT);
            int status;
            while ((status=sqlite3_step(paths.get()))==SQLITE_ROW && !chart) {
                const auto* path=sqlite3_column_text(paths.get(),0);
                if (path) chart=catalog.resolve(hash,reinterpret_cast<const char*>(path),sqlite3_column_int(paths.get(),1));
            }
            if (!chart && status!=SQLITE_DONE) throw std::runtime_error(sqlite3_errmsg(songs.get()));
        }
        if (!chart) {
            // Previously measured charts can still count after a file is moved or removed.
            for (int mode:{5,9,10,14}) if ((chart=catalog.find(hash,mode))) break;
        }
        if (!chart) chart=catalog.fallback(hash);
        if (!chart) {
            for (int mode:{5,9,10,14}) if ((chart=catalog.fallback(hash,mode))) break;
        }
        return chart?&*chart:nullptr;
    });
}
}

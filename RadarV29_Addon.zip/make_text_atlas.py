"""Build the W-mix counter masks and recovery badges from the original skin glyphs."""
import argparse
from pathlib import Path
from PIL import Image, ImageChops, ImageFilter

SCALE = 4
CELL = (20, 32)
BADGE = (48, 24)

def expanded(mask, radius):
    return mask.filter(ImageFilter.MaxFilter(2 * radius + 1))

def supersample(mask):
    return mask.resize(tuple(n*SCALE for n in mask.size), Image.Resampling.BICUBIC)

def reduce(mask, size):
    return mask.resize(size, Image.Resampling.LANCZOS)

def ink(mask, color):
    layer = Image.new('RGBA', mask.size, (*color, 0))
    layer.putalpha(mask)
    return layer

def shifted(mask, x, y):
    out = Image.new('L', mask.size)
    out.paste(mask, (x, y))
    return out

def recovery_badge(traits, percent):
    face = Image.new('L', BADGE)
    label = f'{percent}%'
    for i, ch in enumerate(label):
        u = 48 + 11*(10 if ch == '%' else int(ch))
        glyph = traits.crop((u, 24, u+11, 48))
        face.paste(glyph, (BADGE[0]-2-11*(len(label)-i), 0))
    face = supersample(face)
    blend = max(0., (percent-50)/50.)
    warm = round(194 + (39-194)*percent/100)
    blue = round(111 + (56-111)*percent/100)
    out = Image.new('RGBA', face.size)
    if blend > 0:
        weight = blend**.65
        face = Image.blend(face, expanded(face, 3), weight)
        edge = expanded(face, 3)
        glow = shifted(edge.filter(ImageFilter.GaussianBlur(3)), 2, 3)
        alpha = ImageChops.lighter(glow, edge.point(lambda a: round(a*.74)))
        out.alpha_composite(ink(alpha.point(lambda a: round(a*weight)), (255,255,255)))
    out.alpha_composite(ink(face, (255,warm,blue)))
    return reduce(out, BADGE)

def build(asset_dir, output):
    digits = Image.open(asset_dir/'digits.png').convert('RGBA').getchannel('A')
    traits = Image.open(asset_dir/'traits.png').convert('RGBA').getchannel('A')
    atlas = Image.new('RGBA', (384, 408))
    for glyph in range(11):
        u = 14*glyph
        # Expand the regular cut slightly to keep the counters of 6, 8 and 9 open.
        mask = Image.new('L', CELL)
        mask.paste(digits.crop((u,0,u+14,26)), (3,3))
        face = expanded(supersample(mask), 1)
        rim = expanded(face, 5)
        drop = shifted(expanded(face, 7).filter(ImageFilter.GaussianBlur(2)), 2, 4)
        for row, layer in enumerate((face,rim,drop)):
            atlas.paste(ink(reduce(layer, CELL),(255,255,255)), (20*glyph,32*row))
    for pct in range(1,101):
        atlas.paste(recovery_badge(traits, pct), (48*(pct%8),96+24*(pct//8)))
    atlas.save(output, optimize=True)

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('asset_dir',type=Path)
    parser.add_argument('output',type=Path)
    args = parser.parse_args()
    build(args.asset_dir,args.output)

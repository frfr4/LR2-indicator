#pragma once
#include "v37_scores.hpp"
#include "v38_parameters.hpp"
#include "physical_id.hpp"

namespace chart_radar::v38 {
inline std::string gradeSignature(const DecodedChart& chart,const RadarTempo& timing,double main) {
    // Equal note/scroll geometry, TOTAL, MAIN BPM and tempo history are required for a clone.
    std::uint64_t hash=14695981039346656037ULL;
    auto mix=[&](std::int64_t v){hash=(hash^static_cast<std::uint64_t>(v))*1099511628211ULL;};
    auto fixed=[](double v){return std::llround(v*1000000.);};
    const double origin=chart.notes.empty()?0.:chart.notes.front().start;
    mix(fixed(main));
    for(const auto& t:timing.tempos){mix(fixed(t.first-origin));mix(fixed(t.second));}
    std::ostringstream out;
    out<<physicalId(chart)<<std::hex<<std::setfill('0')<<std::setw(16)<<hash;
    return out.str();
}
struct LampEvidence {
    int tier=0;
    double easy=0.,normal=0.,fullCombo=0.,discrimination=0.;
    bool hasFullCombo=false;
    bool operator==(const LampEvidence& other) const {
        return tier==other.tier && easy==other.easy && normal==other.normal &&
            fullCombo==other.fullCombo && discrimination==other.discrimination &&
            hasFullCombo==other.hasFullCombo;
    }
};
class Grades {
    std::unordered_map<std::string,LampEvidence> byFile,bySignature;
public:
    void load(const std::filesystem::path& file) {
        std::ifstream input(file);std::string md5,signature;LampEvidence e;
        while(input>>md5>>signature>>e.tier>>e.easy>>e.normal>>e.fullCombo>>e.hasFullCombo>>e.discrimination) {
            if(md5.size()!=32 || signature.size()!=48 || e.tier<1 || e.tier>24 || e.discrimination<=0.)continue;
            byFile.emplace(md5,e);
            auto match=bySignature.emplace(signature,e);
            if(!match.second && !(match.first->second==e))match.first->second={};
        }
    }
    LampEvidence find(const std::string& hash,const DecodedChart& chart,const RadarTempo& timing,double main) const {
        auto exact=byFile.find(hash);
        if(exact!=byFile.end())return exact->second;
        if(bySignature.empty())return {};
        auto alias=bySignature.find(gradeSignature(chart,timing,main));
        return alias==bySignature.end()?LampEvidence{}:alias->second;
    }
};
inline double estimateHard(const v37::Measurement& m,const LampEvidence& e) {
    const double n=e.normal, gap=n-e.easy;
    const auto& c=m.context;
    std::array<double,39> x{e.easy,n,gap,std::log1p(std::max(0.,gap)),e.hasFullCombo?e.fullCombo-n:6.,
        e.hasFullCombo?0.:1.,e.discrimination,std::log(e.discrimination),double(e.tier),n-e.tier,
        std::log1p(c[1]/std::max(1.,c[2])),std::log1p(c[11]),std::log1p(c[1]/std::max(1.e-8,c[0])),
        std::log1p(m.main),std::log1p(c[0])};
    v37::Eight strength{};
    for(int a=0;a<v37::Skills;++a)strength[a]=v37::dose(m.summary[0][a])/v37::parameters::ref[a];
    const double top=std::max(1.e-8,*std::max_element(strength.begin(),strength.end()));
    for(int a=0;a<v37::Skills;++a){
        const auto& stats=m.summary[0][a];
        x[15+a]=strength[a]/top;
        x[23+a]=std::log1p(stats[0]/(stats[5]+.1));
        x[31+a]=std::log1p(stats[5]/(stats[4]+.1));
    }
    double logGap=parameters::intercept;
    for(std::size_t j=0;j<x.size();++j)
        logGap+=(x[j]-parameters::lampCenter[j])/parameters::lampScale[j]*parameters::lampCoef[j];
    return n+std::max(0.,std::exp(std::min(6.,logGap))-.05);
}
inline v37::Rating calibrate(const v37::Measurement& m,v37::Rating result,const LampEvidence& e) {
    if(e.tier<1 || e.tier>24)return result;
    const double top=*std::max_element(result.axes.begin(),result.axes.end());
    if(top<=0.)return result;
    const int i=e.tier-1;
    result.hard=estimateHard(m,e);
    const double center=parameters::anchors[i];
    const double delta=v37::ruler(result.hard)-center;
    const double magnitude=std::abs(delta);
    const double adjusted=std::min(magnitude,25.)+std::max(magnitude-25.,0.)*parameters::slopes[i];
    const double calibrated=std::round(std::max(0.,center+std::copysign(adjusted,delta))*100.)/100.;
    const double factor=calibrated/top;
    for(auto& axis:result.axes)axis=std::round(axis*factor*100.)/100.;
    return result;
}
// Preserve measured timestamps, holds, lane masks and scratch input. Only the
// visible scroll and the local BPM used for rhythmic subdivision are neutralized.
inline v37::Rating splitRating(const DecodedChart& chart,std::vector<v37::Frame>& frames,
                               double main,const LampEvidence& grade) {
    const auto full=v37::measureFrames(chart,frames,main);
    auto result=calibrate(full,v37::rating(full),grade);
    if(main<=0.)return result;

    const double mainBeat=60./main;
    bool changed=false;
    for(auto& frame:frames) {
        changed|=frame.read!=0. || frame.beat!=mainBeat;
        frame.read=0.;
        frame.beat=mainBeat;
    }
    if(changed) {
        const auto motor=v37::measureFrames(chart,frames,main);
        const auto physical=calibrate(motor,v37::rating(motor),grade);
        std::copy_n(physical.axes.begin(),v37::Reading,result.axes.begin());
    }
    return result;
}
inline Scores catalogScores(const DecodedChart& chart,const RadarTempo& timing,const std::string& hash,const Grades& grades,double& hard) {
    double main=0.;
    auto frames=v37::timeline(chart,timing,main);
    const auto grade=grades.find(hash,chart,timing,main);
    const auto r=splitRating(chart,frames,main,grade);
    hard=std::round(r.hard*100.)/100.;
    constexpr Axis slots[]{Density,Peak,Stair,Jack,Chord,Stamina,Scratch,Soflan};
    Scores result{};
    for(int i=0;i<8;++i)result[slots[i]]=r.axes[i];
    return result;
}
}

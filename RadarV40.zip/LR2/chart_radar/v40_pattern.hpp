#pragma once
#include "v37_measure.hpp"

namespace chart_radar::v40 {
// One event per chord head. A filler tap preserves the chord-to-chord interval.
struct ChordSequence {
    unsigned mask=0,prior=0,lastRow=0;
    double lastTime=-1.e6,fillerAnchor=0.,contacts=0.;
    double time=0.,priorTime=0.;
    double accept(const v37::Frame& row) {
        const int width=v37::pop(row.keys);
        const double gap=std::max(.001,row.t-lastTime);
        const double edgeSpeed=1./(1.+std::pow(gap/.16,3));
        const int rowRepeat=v37::pop(lastRow & row.keys);
        const bool afterSingle=v37::pop(lastRow)==1;
        lastRow=row.keys;lastTime=row.t;
        if(width<2) {
            if(mask)fillerAnchor+=rowRepeat*edgeSpeed/(1.+std::pow((row.t-time)/.20,3));
            return 0.;
        }
        if(!mask) {mask=row.keys;time=row.t;return 0.;}
        const int shared=v37::pop(mask & row.keys);
        const double dt=std::max(.001,row.t-time);
        const double tempo=1./(1.+std::pow(dt/.20,3));
        const double fraction=shared/std::sqrt(double(width*std::max(1,v37::pop(mask))));
        const double recurring=v37::pop(prior & mask & row.keys)/(1.+std::pow((time-priorTime)/.20,3));
        priorTime=time;
        contacts+=shared*tempo;
        const double anchoredTaps=(afterSingle?rowRepeat*edgeSpeed:0.)+fillerAnchor;
        const double movingFingers=v37::pop(mask ^ row.keys);
        const double cost=(shared*fraction+.35*recurring+.65*anchoredTaps)*std::sqrt(double(width-1))*tempo
            *(1.+.12*movingFingers);
        fillerAnchor=0.;
        prior=mask;
        time=row.t; mask=row.keys;
        return cost;
    }
};
struct FingerPath {
    v37::Hand hand;
    double accept(unsigned mask,double time) {
        if(!mask)return 0.;
        double turns=0.;
        const double steps=v37::fingerTriples(hand.back,hand.prev,mask,turns);
        const double gap=time-hand.t,prior=hand.t-hand.prior;
        const double uneven=std::abs(gap-prior)/std::max(.001,gap+prior);
        const double clarity=1./std::max(1,v37::pop(mask)*v37::pop(hand.prev)*v37::pop(hand.back));
        const double speed=1./(.035+std::max(gap,prior));
        const double cost=hand.back==mask?0.:(steps+turns*(.5+uneven))*speed*speed*clarity;
        hand.prior=hand.t;hand.t=time;hand.back=hand.prev;hand.prev=mask;
        return cost;
    }
};
inline double streamCost(unsigned mask,unsigned previous,double gap,double prior) {
    const double fresh=v37::pop(mask & ~previous);
    const double speed=1./(1.+std::pow(std::max(gap,prior)/.22,2));
    const double regularity=std::min(gap,prior)/std::max(.001,std::max(gap,prior));
    return fresh/std::sqrt(double(v37::pop(mask)))*speed*(.75+.25*regularity);
}
}

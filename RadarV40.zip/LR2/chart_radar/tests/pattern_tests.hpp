#pragma once
static DecodedChart pattern(const std::vector<unsigned>& shapes,double step=0.09) {
    DecodedChart c{{},{},400.,bms::Layout(7)};
    for(int i=0;i<700;++i) {
        const double t=i*step;
        for(int lane=0;lane<7;++lane)if(shapes[i%shapes.size()]&(1u<<lane))
            c.notes.push_back({t,t,lane,.4});
    }
    return c;
}
static bool patternChecks() {
    RadarTempo tempo;tempo.tempos={{0.,150.}};tempo.mainVotes[150.]=1000;
    const auto stream=measure(pattern({1,16,2,32,4,64,8}),tempo);
    const auto chordstream=measure(pattern({3,12}),tempo);
    const auto chordjack=measure(pattern({3,5}),tempo);
    const auto jack=measure(pattern({1}),tempo);
    const auto trill=measure(pattern({1,2}),tempo);
    if(chordstream.raw[v37::Chords]!=0. || chordjack.raw[v37::Chords]<=0. || jack.raw[v37::Chords]!=0.)return false;
    if(stream.raw[v37::Notes]<=jack.raw[v37::Notes] || stream.raw[v37::Delay]<=0. || trill.raw[v37::Delay]!=0.)return false;
    if(jack.raw[v37::Repeat]<=stream.raw[v37::Repeat])return false;
    ChordSequence bare,fill;
    auto row=[](unsigned mask,double t){return v37::Frame{t,.4,0.,mask,0,false};};
    bare.accept(row(3,0.));const double before=bare.accept(row(5,.15));
    fill.accept(row(3,0.));fill.accept(row(16,.075));if(fill.accept(row(5,.15))<before)return false;
    ChordSequence lone;lone.accept(row(1,0.));if(lone.accept(row(3,.075))!=0.)return false;
    return true;
}
static bool judgeChecks(const std::filesystem::path& temp) {
    std::filesystem::create_directories(temp);
    const auto bms=temp/"window.bms";
    const std::string hash="00000000000000000000000000000000";
    v40::Grades empty;
    std::optional<Scores> original;
    std::array<double,4> estimate{};
    for(int rank=0;rank<6;++rank){
        {
            std::ofstream out(bms);
            out<<"#PLAYER 1\n#BPM 180\n#TOTAL 400\n";
            if(rank!=4)out<<"#RANK "<<rank<<"\n";
            for(int i=0;i<10;++i)
                for(int lane=1;lane<=5;++lane)out<<'#'<<std::setw(3)<<std::setfill('0')<<i<<'1'<<lane<<":01010101\n";
        }
        RadarTempo t;const auto c=decodeChart(bms,7,1,&t);
        if(c.judgeRank!=(rank<=3?rank:2))return false;
        double hard=0.;const auto scores=catalogScores(c,t,hash,empty,hard);
        if(original && *original!=scores)return false;
        original=scores;
        if(rank<4)estimate[rank]=hard;else if(hard!=estimate[2])return false;
    }
    if(!(estimate[0]>estimate[1] && estimate[1]>estimate[2] && estimate[2]>estimate[3]))return false;
    return true;
}

#pragma once
#include "v40_measure.hpp"
#include "v40_parameters.hpp"
#include <optional>

namespace chart_radar::v40 {
struct Lamp {
    int star=0,oj=-1;
    double easy=0.,normal=0.,fc=-1.,dis=1.;
    bool operator==(const Lamp& x) const {
        return star==x.star&&oj==x.oj&&easy==x.easy&&normal==x.normal&&fc==x.fc&&dis==x.dis;
    }
};
class Grades {
    std::unordered_map<std::string,Lamp> byFile;
    std::unordered_map<std::string,std::optional<Lamp>> aliases;
public:
    void load(const std::filesystem::path& file) {
        std::ifstream input(file);std::string hash,sig;Lamp lamp;
        while(input>>hash>>sig>>lamp.star>>lamp.oj>>lamp.easy>>lamp.normal>>lamp.fc>>lamp.dis) {
            if(hash.size()!=32||sig.size()!=49||lamp.star<0||lamp.star>24||lamp.oj< -1||lamp.oj>6||lamp.dis<=0.)continue;
            byFile.emplace(hash,lamp);
            auto [it,inserted]=aliases.emplace(sig,lamp);
            if(!inserted && it->second && !(*it->second==lamp))it->second.reset();
        }
    }
    std::optional<Lamp> find(const std::string& hash,const DecodedChart& c,const RadarTempo& t,double main) const {
        auto it=byFile.find(hash);if(it!=byFile.end())return it->second;
        if(aliases.empty())return {};
        auto alias=aliases.find(v38::gradeSignature(c,t,main)+char('0'+c.judgeRank));
        return alias==aliases.end()?std::optional<Lamp>{}:alias->second;
    }
};
constexpr std::array<int,7> hardAxes{v37::Notes,v37::Burst,v37::Delay,v37::Repeat,v37::Chords,v37::Deck,v37::Reading};
using Features=std::array<double,21>;
inline Features features(const Lamp& e,const Evidence& measured,double total,int count) {
    const double n=e.normal,gap=std::max(0.,n-e.easy),dis=std::max(.1,e.dis);
    Features x{1.,n/20.,gap,std::log1p(gap),1./dis,std::log(dis),gap/(1.+dis),
        e.fc<0?5.:e.fc-n,e.fc<0?1.:0.,std::max(0.,n-21.)/3.,double(e.star),double(e.oj),
        std::log1p(total),std::log1p(double(count))};
    for(size_t i=0;i<hardAxes.size();++i)x[14+i]=std::log1p(measured.raw[hardAxes[i]]);
    return x;
}
inline double lampEstimate(const Lamp& e,const Features& x) {
    const double linear=std::inner_product(std::begin(parameters::lamp),std::end(parameters::lamp),x.begin(),0.);
    double gap=std::max(0.,std::sinh(std::clamp(linear,-4.,4.)));
    if(e.fc>=0.) {
        const double room=std::max(0.,e.fc-e.normal);
        gap=gap*room/std::max(1.e-8,room+gap);
    }
    return e.normal+gap;
}
inline double absoluteScore(int axis,double value) {
    if(axis==v37::Endurance)return 20.*value;
    constexpr double marks[]{150.,355.,515.,655.,750.};
    const auto& q=parameters::doses;
    double lo=0.,base=0.;
    for(int i=0;i<5;++i) {
        const double hi=q[i][axis];
        if(value<=hi)return base+(marks[i]-base)*(value-lo)/(hi-lo);
        lo=hi;base=marks[i];
    }
    const double slope=(marks[4]-marks[2])/(q[4][axis]-q[2][axis]);
    return 750.+450.*std::log1p((value-lo)*slope/450.);
}
inline double fallbackHard(double peak) {
    if(peak<=0.)return 0.;
    if(peak<100.)return std::max(0.,3.+3.*std::log(peak/100.));
    if(peak<=200.)return 3.+(peak-100.)/50.;
    if(peak<=700.)return 5.+(peak-200.)*18./500.;
    return 23.+(peak-700.)/50.;
}
inline double clampLamps(const Lamp& e,double v) {
    const double h=std::max(e.normal,v);
    return e.fc<0.?h:std::min(e.fc,h);
}
inline double judgementCost(int rank) {
    // GOOD is the outermost positive judgement in the standard SP BMS loader.
    constexpr double goodWindowMs[]{40.,60.,100.,120.};
    return std::log(100./goodWindowMs[rank>=0 && rank<=3?rank:2]);
}
template<size_t N> inline double forest(int model,const std::array<double,N>& input) {
    double result=parameters::bias[model];
    for(int i=parameters::modelOffset[model];i<parameters::modelOffset[model+1];++i) {
        int j=parameters::roots[i];
        while(parameters::nodes[j].field>=0) {
            const auto& node=parameters::nodes[j];
            j=input[node.field]<=node.cut?node.left:node.right;
        }
        result+=parameters::nodes[j].value;
    }
    return result;
}
inline double upperLamp(const Lamp& e,const Features& x,double base) {
    const double gap=x[2],n=e.normal;
    const std::array<double,12> features{1.,x[3],x[4],x[5],gap/(1.+gap),
        std::max(0.,n-24.),std::max(0.,25.-n),x[8],std::log1p(std::max(0.,x[7])),
        std::max(0.,double(e.oj-3)),std::clamp(double(e.oj),0.,3.),x[3]*x[4]};
    const double gapHigh=std::inner_product(features.begin(),features.end(),parameters::upper,0.);
    const double weight=std::clamp((n-21.)/3.,0.,1.);
    return clampLamps(e,(1.-weight)*base+weight*(n+gapHigh));
}
inline double predictHard(const Lamp& e,const Features& common,const Evidence& m,double base,int rank) {
    std::array<double,26> x{};
    std::copy(common.begin(),common.end(),x.begin());
    const double heads=std::max(1.,m.keyHeads),rows=std::max(1.,m.keyRows);
    x[21]=std::log1p(m.keyHeads/std::max(1.,m.duration));x[22]=m.freshKeys/heads;
    x[23]=m.rhythmicContinuity/rows;x[24]=m.chordContacts/heads;
    x[25]=std::log1p(m.keyRows/std::max(1.,m.duration));
    return clampLamps(e,base+parameters::judge*judgementCost(rank)+forest(0,x));
}
struct Scale { double anchor,reference,keyDose,pivot; };
inline Scale scale(const Lamp& e,double upper,const Evidence& m) {
    const bool star=e.star>0,dual=star && e.oj>=0;
    const double ref=v37::ruler(upper),center=star?v38::parameters::anchors[e.star-1]:0.;
    double anchor=ref,pivot=parameters::ojPivot;
    if(star) {
        anchor=dual?std::clamp(ref,center-40.,center+40.):center+15.*std::tanh((ref-center)/55.);
        pivot=parameters::pivot[e.star-1];if(dual)pivot=std::min(pivot,parameters::ojPivot);
    }
    anchor=std::max(60.,anchor);
    const double rate=std::log1p(m.keyHeads/std::max(.01,m.duration));
    const std::array<double,5> context{1.,rate,rate*rate,std::log1p(m.duration)/5.,std::log1p(anchor)/6.};
    const double estimate=std::expm1(std::inner_product(context.begin(),context.end(),parameters::geometry,0.));
    const double physical=std::clamp(estimate,.4*anchor,2.7*anchor);
    return {anchor,ref,(1.-parameters::geometryWeight)*anchor+parameters::geometryWeight*physical,pivot};
}
inline double calibrated(int axis,int model,const Evidence& m,const Lamp& e,const Features& x,
                         const Scale& ruler,double upper,double physical) {
    std::array<double,15> evidence{};
    std::copy_n(x.begin(),13,evidence.begin());
    evidence[13]=axis<v37::Endurance?std::log1p(m.keyHeads):0.;evidence[14]=std::log1p(m.raw[axis]);
    const double predicted=clampLamps(e,upper+forest(model,evidence));
    double anchor=parameters::blend*v37::ruler(predicted)+(1.-parameters::blend)*ruler.reference;
    if(e.star>0) {
        const double center=v38::parameters::anchors[e.star-1];
        anchor=e.oj<0?ruler.anchor:std::clamp(anchor,center-39.,center+39.);
    }
    constexpr double factors[]{1.,1.14,1.10,1.,1.06,1.,1.,1.};
    const double denom=axis<v37::Endurance?ruler.keyDose:ruler.anchor;
    const double ratio=physical/(factors[axis]*denom*ruler.pivot);
    const double spread=parameters::spread;
    if(ratio<1.)return (anchor-spread)*ratio*ratio*ratio;
    return anchor-spread+2.*spread*std::tanh(ratio-1.);
}
inline Scores catalogScores(const DecodedChart& chart,const RadarTempo& timing,const std::string& hash,const Grades& grades,double& hard) {
    const auto measured=measure(chart,timing);
    double main=0.;int votes=-1;
    for(const auto& entry:timing.mainVotes)
        if(entry.second>votes || (entry.second==votes&&entry.first>main)){votes=entry.second;main=entry.first;}
    if(main<=0.&&!timing.tempos.empty())main=timing.tempos.front().second;
    const auto e=grades.find(hash,chart,timing,main);
    std::optional<Scale> grading;Features common{};double upper=0.;
    if(e) {
        const int count=gaugeNoteCount(chart);
        common=features(*e,measured,chart.total>0.?chart.total:defaultGaugeTotal(count),count);
        const double base=lampEstimate(*e,common);
        upper=upperLamp(*e,common,base);grading=scale(*e,upper,measured);
        hard=predictHard(*e,common,measured,base,chart.judgeRank);
    }
    constexpr Axis slots[]{Density,Peak,Stair,Jack,Chord,Stamina,Scratch,Soflan};
    Scores result{};double top=0.;int model=0;
    for(int i=0;i<v37::Skills;++i) {
        const double physical=absoluteScore(i,measured.raw[i]);double value=physical;
        if(i!=v37::Endurance) {
            ++model;if(e)value=calibrated(i,model,measured,*e,common,*grading,upper,physical);
        }
        if(i==v37::Notes || i==v37::Burst || i==v37::Repeat)value=std::min(value,physical+220.);
        if(i==v37::Chords) {
            const double share=measured.chordContacts/std::max(1.,measured.keyHeads);
            value=std::min(value,physical*(parameters::chordFloor+1.75*std::sqrt(share)));
        }
        if(i==v37::Delay) {
            const double keyRate=measured.keyHeads/std::max(.01,measured.duration);
            const double clarity=measured.raw[i]/std::max(1.,keyRate*keyRate);
            value=std::min(value,physical*(parameters::delayFloor+.16*std::log1p(clarity)));
        }
        result[slots[i]]=std::round(100.*value)/100.;
        if(i!=v37::Endurance)top=std::max(top,result[slots[i]]);
    }
    if(!e)hard=top>0.?std::max(0.,fallbackHard(top)+parameters::judge*judgementCost(chart.judgeRank)):0.;
    hard=std::round(100.*hard)/100.;return result;
}
}

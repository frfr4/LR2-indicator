#include "catalog.hpp"
#include <iostream>
using namespace chart_radar;
using namespace chart_radar::v40;
#include "pattern_tests.hpp"
static bool isolation() {
    Evidence m;
    m.raw.fill(12.);m.duration=120.;m.keyHeads=2100.;
    const Lamp lamp{18,3,18.,21.,28.,2.};
    for(int which=0;which<v37::Skills;++which) {
        auto other=m;other.raw[which]*=4.;
        const auto x=features(lamp,m,500,3200),y=features(lamp,other,500,3200);
        const double base=lampEstimate(lamp,x),upper=upperLamp(lamp,x,base);
        const auto scaleA=scale(lamp,upper,m),scaleB=scale(lamp,upper,other);
        int model=0;
        for(int a:hardAxes) {
            ++model;if(a==which)continue;
            const double phys=absoluteScore(a,m.raw[a]);
            if(calibrated(a,model,m,lamp,x,scaleA,upper,phys)!=calibrated(a,model,other,lamp,y,scaleB,upper,phys))return false;
        }
        if(which==v37::Endurance && predictHard(lamp,x,m,base,2)!=predictHard(lamp,y,other,base,2))return false;
    }
    DecodedChart plain{{},{},400.,bms::Layout(7)};RadarTempo steady;
    steady.tempos={{0.,150.}};steady.mainVotes[150.]=1000;
    for(int i=0;i<850;++i){double t=i*.125;plain.notes.push_back({t,t,i%7,t*2.5});}
    auto scratched=plain;
    for(int i=0;i<849;++i){double t=(i+.4)*.125;scratched.notes.push_back({t,t,7,t*2.5});}
    std::stable_sort(scratched.notes.begin(),scratched.notes.end(),[](const auto& x,const auto& y){return x.start<y.start;});
    auto speed=plain;speed.changes={{10.,.125,0.,false},{40.,8.,0.,false}};
    auto a=measure(plain,steady),b=measure(scratched,steady),c=measure(speed,steady);
    if(b.raw[v37::Deck]<=a.raw[v37::Deck] || c.raw[v37::Reading]<=a.raw[v37::Reading])return false;
    for(int i=0;i<=v37::Endurance;++i)if(a.raw[i]!=b.raw[i] || a.raw[i]!=c.raw[i])return false;
    return true;
}
int main(int argc,char**argv) {
    if(argc!=4||!isolation()||!patternChecks()||!judgeChecks(argv[3]))return 1;
    namespace fs=std::filesystem;
    fs::path assets=argv[1],tests=argv[2],temp=argv[3];fs::create_directories(temp);
    ChartCatalog db((assets/"charts.tsv").string());
    std::ifstream table(assets/"charts-v40.tsv");std::string line;int count=0;
    while(std::getline(table,line)){
        std::istringstream in(line);std::string h;in>>h;auto scores=db.find(h);
        if(!scores)return 2;
        for(auto a:detailOrder){double value;if(!(in>>value)||(*scores)[a]!=value)return 3;}
        int late,low,poor;double hard;
        if(!(in>>late>>low>>poor>>hard)||db.hardEstimate(h)!=hard||db.poorExtra(h,7)!=poor)return 4;
        ++count;
    }
    if(count!=1959)return 5;
    std::array<int,31> n{},hits{};std::string h;int star,oj;double truth;
    std::ifstream labels(tests/"test-labels.tsv");
    while(labels>>h>>star>>oj>>truth){
        const auto scores=db.find(h);const auto hard=db.hardEstimate(h);if(!scores||!hard)return 6;
        double top=0.;for(auto a:detailOrder)if(a!=Stamina)top=std::max(top,(*scores)[a]);
        const bool correct=std::abs(std::llround(*hard*100)-std::llround(truth*100))<=(truth>25.?50:100);
        auto record=[&](int i,double middle){++n[i];hits[i]+=correct && std::abs(top-middle)<=(i>=24 && truth>25.?25.:50.)+1.e-8;};
        if(star>0)record(star-1,v38::parameters::anchors[star-1]);
        if(oj>=0)record(24+oj,v37::ruler(truth));
    }
    for(int i=0;i<31;++i){std::cout<<i<<" "<<hits[i]<<"/"<<n[i]<<"\n";if(!n[i]||100*hits[i]<(i<24?90:85)*n[i])return 7;}
    std::string hash;std::ifstream(tests/"fixture.hash")>>hash;
    const std::string bms=(tests/"fixture.bms").string();
    for(int i=0;i<2;++i){
        ChartCatalog unregistered((temp/"no-catalog.tsv").string(),(temp/"cache.sqlite").string());
        const auto actual=i?unregistered.find(hash):unregistered.resolve(hash,bms,7,true);
        if(!actual||!unregistered.hardEstimate(hash)||(*actual)[Density]<=0)return 8;
    }
    std::cout<<"1959 profiles; 31 grade gates; independent axes, stream/chordjack/delay, rank windows and endurance; warm cache passed.\n";
}

#pragma once
#include "presentation.hpp"
namespace chart_radar::v41 {
struct Ink { RGB edge; int glow; };
inline double unit(double x) {return std::clamp(x,0.,1.);}
inline RGB between(RGB a,RGB b,double t) {
    RGB out{};for(size_t i=0;i<out.size();++i)out[i]=int(std::lround(a[i]+(b[i]-a[i])*unit(t)));
    return out;
}
inline Ink ink(int row,double value) {
    constexpr RGB white{255,255,255},red{255,51,65},pink{255,107,188},purple{181,110,255};
    const double floor=row==0?-1.02:row==1?1.73:0.;
    const double fraction=unit((value-floor)/((row<2?25.:50.)-floor));
    const double t=fraction*fraction*(3.-2.*fraction);
    RGB rim=between(white,red,t);
    if(row<2 && value>25.)rim=value<=26.5?between(red,pink,(value-25.)/1.5):between(pink,purple,(value-26.5)/1.5);
    return {rim,int(std::lround(t*255.))};
}
}

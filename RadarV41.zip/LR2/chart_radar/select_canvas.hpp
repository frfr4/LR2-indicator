#pragma once
#include "display.hpp"
#include "clear_style.hpp"
#include <DxLib.h>
#include <chrono>
#include <vector>

namespace chart_radar {
inline constexpr const char* assetDir="LR2files/Theme/KCOOL_WMIX_FHD/WMIX/select/radar/";
struct SelectCanvas {
    int textures[10]{-1,-1,-1,-1,-1,-1,-1,-1,-1,-1};
    double sx=1.,sy=1.;
#ifdef _WIN32
    std::vector<POINTDATA> outlinePixels;
#endif
    std::chrono::steady_clock::time_point retryOptional[5]{};
    bool load() {
        const char* files[]{"song.png","player.png","digits.png","tiers.png","shadows.png","traits.png","rating-text-v29.png","traits-80.png","hard-poor-ink.png","selection-v41.png"};
        constexpr int widths[]{540,540,154,68,220,274,384,274,400,274};
        constexpr int heights[]{850,850,52,1534,1920,48,408,648,504,180};
        for (int i=0;i<std::size(files);++i) {
            int w=0,h=0;
            if (textures[i]>=0 && GetGraphSize(textures[i],&w,&h)==0 && w==widths[i] && h==heights[i]) continue;
            if (i>=5 && std::chrono::steady_clock::now()<retryOptional[i-5]) continue;
            textures[i]=LoadGraph((std::string(assetDir)+files[i]).c_str());
            if (textures[i]<0) {
                if (i<5) return false;
                retryOptional[i-5]=std::chrono::steady_clock::now()+std::chrono::seconds(5);
                continue;
            }
            SetDeleteHandleFlag(textures[i], &textures[i]);
        }
        return true;
    }
    int x(int px) const {return static_cast<int>(std::lround((Panel::x+px)*sx));}
    int y(int py) const {return static_cast<int>(std::lround((Panel::y+py)*sy));}
    static unsigned color(const RGB& c) {return GetColor(c[0],c[1],c[2]);}
    void back(bool player) {
        SetDrawBright(255,255,255);
        const int plate=player?1:0;
        for (int i=0;i<int(radarClockwise.size());++i)
            triangle(Panel::center,Panel::point(i,1.),Panel::point((i+1)%radarClockwise.size(),1.),{25,39,52});
        if(player) {
            sprite({60,539},60,539,420,72,plate);
            sprite({60,611},60,644,420,206,plate);
            return;
        }
        int src=539,dest=539-78;
        for(int row=0;row<Count;++row) {
            const int cut=585+int(std::lround(row*32.8));
            const int height=cut-src;
            // Row 1 contains the NOTES label, row 2 the retired PEAK label.
            if(row!=2){sprite({60,dest},60,src,420,height,plate);dest+=height;}
            src=cut+Panel::songRowTrim;
        }
        sprite({60,dest},60,src,420,850-src,plate);
    }
    void labels(bool player) {
        struct Label {int u,v,w,h;};
        static constexpr Label labels[]={{273,40,58,18},{448,231,55,18},{405,425,78,19},
            {234,498,72,19},{53,425,77,19},{27,231,46,19},{65,81,56,20}};
        for(int i=0;i<int(radarClockwise.size());++i) {
            const auto l=labels[i];
            const double a=i*(6.283185307179586/7.),sn=std::sin(a);
            const int dx=int(std::lround(135.*sn+(sn>.2?.28:sn<-.2?-.28:0.)*l.w-.5*l.w));
            const int dy=int(std::lround(-132.*std::cos(a)-.5*l.h));
            sprite({Panel::center.x+dx,Panel::center.y+dy},l.u,l.v,l.w,l.h,player?1:0);
        }
    }
    void triangle(Point a,Point b,Point c,RGB ink) {
        DrawTriangle(x(a.x),y(a.y),x(b.x),y(b.y),x(c.x),y(c.y),color(ink),TRUE);
    }
    void line(Point a,Point b,RGB ink,int width=1) {
        const int thickness=std::max(1,static_cast<int>(std::lround(width*std::min(sx,sy))));
        DrawLine(x(a.x),y(a.y),x(b.x),y(b.y),color(ink),thickness);
    }
    void outline(const Tips& tips,RGB ink,int width) {
        const unsigned rgb=color(ink);
        const double scale=std::min(sx,sy);
#ifdef _WIN32
        outlinePixels.clear();
        auto plot=[&](int px,int py) {outlinePixels.push_back({px,py,rgb,255});};
#else
        auto plot=[&](int px,int py) {DrawPixel(px,py,rgb);};
#endif
        for (int i=0;i<int(tips.size());++i) {
            const auto a=tips[i],b=tips[(i+1)%tips.size()];
            rasterEdge({x(a.x),y(a.y)},{x(b.x),y(b.y)},std::max(1.,width*scale),
                       std::max(1.,14.*scale),plot);
        }
#ifdef _WIN32
        DrawPixelSet(outlinePixels.data(),int(outlinePixels.size()));
#endif
    }
    void sprite(Point pos,int u,int v,int w,int h,int texture) {
        DrawRectExtendGraph(x(pos.x),y(pos.y),x(pos.x+w),y(pos.y+h),u,v,w,h,textures[texture],TRUE);
    }
    void tint(RGB ink) {SetDrawBright(ink[0],ink[1],ink[2]);}
    void tier(int label,RGB ink,Shadow shadow) {
        if (shadow) {
            tint(*shadow);
            sprite({316,473},0,(label+1)*32,74,32,4);
        }
        tint(ink);
        sprite({319,476},0,label*26,68,26,3);
        SetDrawBright(255,255,255);
    }
    void selectionRow(int row,std::optional<double> value) {
        if(textures[9]<0)return;
        const int left=133,top=725+25*row;
        tint({255,255,255});
        sprite({left,top},0,row*24,274,24,9);
        char text[56];
        if(value)std::snprintf(text,sizeof(text),row<2?"*%.2f":"%.2f",*value);
        else std::snprintf(text,sizeof(text),"-");
        const auto ink=v41::ink(row,value.value_or(row<2?-10.:0.));
        const auto width=[](char c){return c=='.'?5:c=='*'?15:c=='-'?8:10;};
        const int edge=left+(row<2?264:198);
        const auto layer=[&](int band,RGB color) {
            int pen=edge;
            tint(color);
            for(const char* end=text+std::char_traits<char>::length(text);end!=text;) {
                const char c=*--end;const int step=width(c);
                const int index=c=='.'?10:c=='-'?11:c=='*'?12:c-'0';
                sprite({pen-step/2-10,top-2},index*20,96+28*band,20,28,9);
                pen-=step;
            }
        };
        if(ink.glow && value){SetDrawBlendMode(DX_BLENDMODE_ALPHA,ink.glow);layer(2,ink.edge);}
        SetDrawBlendMode(DX_BLENDMODE_ALPHA,255);
        layer(1,ink.edge);layer(0,{0,0,0});tint({255,255,255});
    }
    void chartTraits(ChartTraits info) {
        drawTraits(info.endSpike,displayedShortfall(info.recoveryShortfall));
    }
    void hardPoor(int cents) {
        if (textures[8]<0) return;
        constexpr int left=263,top=849;
        SetDrawBright(255,255,255);
        sprite({left,top},0,0,144,24,8);
        if (cents==0) {
            sprite({left+127,top},144,0,8,24,8);
            return;
        }
        // Each 40x24 cell contains one side of the fixed decimal point.
        const int whole=cents/100, fraction=cents%100;
        sprite({left+71,top},40*(whole%10),24*(1+whole/10),32,24,8);
        sprite({left+103,top},40*(fraction%10),24*(11+fraction/10),40,24,8);
    }
    void drawTraits(bool endSpike,int percent) {
        // The approved footer atlas keeps the original panel and text anchors.
        // Older skins still use their original plate and number sheets.
        const int plate=textures[7]>=0?7:5;
        if (textures[plate]<0) return;
        constexpr int left=133,top=825;
        SetDrawBright(255,255,255);
        sprite({left,top},0,0,274,24,plate);
        sprite({left+102,top},endSpike?0:16,24,16,24,plate);
        if (percent==0) {
            sprite({left+247,top},32,24,16,24,plate);
            return;
        }
        if (plate==7) {
            const int badge=percent-1;
            sprite({left+208,top},64*(badge%4),48+24*(badge/4),64,24,plate);
            return;
        }
        if (textures[6]>=0) {
            sprite({left+217,top},48*(percent%8),96+24*(percent/8),48,24,6);
            return;
        }
        std::string text=std::to_string(percent)+"%";
        int at=left+263-int(text.size())*11;
        for (char c:text) {
            const int glyph=c=='%'?10:c-'0';
            sprite({at,top},48+11*glyph,24,11,24,5);
            at+=11;
        }
    }
    void number(Point pos,double value,bool detail) {
        char text[32];std::snprintf(text,sizeof(text),"%.2f",value);
        const bool bold=boldRating(value);
        const auto band=detail && textures[6]>=0 ? detailBand(value) : DetailBand::Standard;
        // Finish each layer across the whole number before drawing the next so
        // the shadows of adjoining glyphs cannot cover their counters.
        auto draw=[&](int texture,int cell,int row,int height,int pad,RGB ink) {
            tint(ink);
            int right=pos.x;
            for (const char* end=text+std::char_traits<char>::length(text);end>text;) {
                const char ch=*--end;
                const int glyph=ch=='.'?10:ch-'0';
                const int advance=ch=='.'?6:(bold?14:13);
                const int left=right-advance-(14-advance)/2;
                sprite({left-pad,pos.y-13-pad},cell*glyph,row,cell,height,texture);
                right-=advance;
            }
        };
        if (band==DetailBand::Standard) {
            if (auto shadow=ratingShadow(value)) draw(4,20,0,32,3,*shadow);
            draw(2,14,bold?26:0,26,0,ratingColor(value));
        } else {
            if (band==DetailBand::Monochrome) draw(6,20,64,32,3,{0,0,0});
            RGB outline=band==DetailBand::Red ? RGB{255,66,83} :
                band==DetailBand::Inverted ? RGB{54,57,62} : RGB{255,255,255};
            if (band==DetailBand::Inverted) draw(6,20,64,32,3,outline);
            draw(6,20,32,32,3,outline);
            draw(6,20,0,32,3,band==DetailBand::Inverted ? RGB{255,255,255} : RGB{0,0,0});
        }
        SetDrawBright(255,255,255);
    }
};
}

#pragma once
#include "v40_measure.hpp"
#include "clear_model.hpp"

namespace chart_radar::v41 {
struct SelectionStats {
    double average=0.,maximum=0.;
    std::optional<double> easy,hard;
};
using Features=std::array<double,36>;
struct Section { int hits=0; double jack=0.,chord=0.,scratch=0.; };

// Integrate real tempo over each distinct occupied quarter note, skipping empty
// beats and stops. Multiple heads on the same beat add inputs, not duration.
inline double activeSeconds(const std::vector<Note>& notes,const RadarTempo& timing) {
    size_t index=0; double seconds=0.,previous=-1.;
    const auto& changes=timing.beatTempos;
    for(const auto& note:notes) {
        const double beat=std::floor(note.beat+1.e-9);
        if(beat==previous)continue;
        previous=beat;
        while(index+1<changes.size() && changes[index+1].first<=beat)++index;
        double from=beat;
        while(index+1<changes.size() && changes[index+1].first<beat+1.) {
            const auto next=changes[index+1].first;
            seconds+=(next-from)*60./changes[index].second;
            from=next;++index;
        }
        seconds+=(beat+1.-from)*60./changes[index].second;
    }
    return seconds;
}
// Each probe predicts the share of mistakes from local demand at a hypothetical
// playing speed. EASY uses the ending gauge, HARD the lowest gauge reached.
inline double requiredSpeed(const std::array<Section,80>& parts,double span,
                            double total,int heads,double damage,bool easy) {
    double lower=0.,upper=300.;
    for(int step=0;step<14;++step) {
        const double skill=(lower+upper)*.5;
        double gauge=easy?20.:100.,minimum=gauge;
        for(const auto& p:parts) {
            if(!p.hits)continue;
            const double demand=p.hits/span + .12*p.jack/p.hits + 3.*p.chord/p.hits + 2.*p.scratch/p.hits;
            const double error=1./(1.+std::exp(std::clamp((skill-demand)/4.0,-40.,40.)));
            const double gain=easy?1.2*total/heads:.1;
            const double loss=easy?4.8:10.*damage*(gauge<=30.?.6:1.);
            gauge=std::clamp(gauge+p.hits*((1.-error)*gain-error*loss),easy?2.:0.,100.);
            minimum=std::min(minimum,gauge);
        }
        if(easy?gauge>=80.:minimum>0.)upper=skill;else lower=skill;
    }
    return upper;
}
inline Features measure(const DecodedChart& chart,const RadarTempo& tempo,SelectionStats& stats) {
    Features x{}; if(chart.notes.empty() || tempo.beatTempos.empty())return x;
    std::vector<Note> heads;
    std::array<double,18> held,previous;held.fill(-1.e30);previous=held;
    for(const auto& n:chart.notes)if(n.start>held[n.lane]) {
        heads.push_back(n);held[n.lane]=n.end;
    }
    const int count=static_cast<int>(heads.size());
    const double total=chart.total>0.?chart.total:defaultGaugeTotal(count);
    const double damage=hardDamageMultiplier(count,static_cast<int>(total));
    const double active=activeSeconds(heads,tempo);
    const double origin=heads.front().start;
    const double duration=heads.back().start-origin;
    const double window=duration>1.e-8?duration*.025:active;
    const double span=std::max(window/2.,1.e-9);
    std::array<Section,80> parts{};
    int scratch=0,holds=0,peak=0;size_t left=0;
    const int keys=chart.layout.perSide*chart.layout.sides;
    for(size_t i=0;i<heads.size();) {
        const double t=heads[i].start;size_t end=i+1;
        while(end<heads.size() && heads[end].start==t)++end;
        while(left<i && t-heads[left].start>=window-1.e-10)++left;
        peak=std::max(peak,static_cast<int>(end-left));
        auto& part=parts[std::clamp(int((t-origin)/span),0,79)];
        const int chord=int(end-i);part.hits+=chord;part.chord+=chord*(chord-1);
        for(;i<end;++i) {
            const auto& n=heads[i];
            if(n.lane>=keys){++scratch;++part.scratch;}
            holds+=n.end>t;
            const double dt=t-previous[n.lane];previous[n.lane]=t;
            if(dt<1.){const double rate=1./std::max(.018,dt);part.jack+=rate*rate;}
        }
    }
    stats.average=count/std::max(1.e-9,active);stats.maximum=peak/std::max(1.e-9,window);
    std::array<double,80> rates{};double worst=0.,worstJack=0.,worstChord=0.,tail=0.;
    for(int i=0;i<80;++i) {
        const auto& p=parts[i];rates[i]=p.hits/span;worst=std::max(worst,rates[i]);
        if(i>=72)tail=std::max(tail,rates[i]);
        if(p.hits){worstJack=std::max(worstJack,p.jack/p.hits);worstChord=std::max(worstChord,p.chord/p.hits);}
    }
    const double last=(rates[78]+rates[79])*.5;
    std::sort(rates.begin(),rates.end());
    const auto p=assessPassages(heads,keys,total);
    x={stats.average,stats.maximum,double(count),duration,total,total/count,damage,double(chart.judgeRank),
       rates[40],rates[60],rates[72],rates[76],worst,tail,last,worstJack,worstChord,
       double(scratch)/count,double(holds)/count,requiredSpeed(parts,span,total,count,damage,true),
       requiredSpeed(parts,span,total,count,damage,false),double(p.traits.endSpike),double(p.traits.recoveryShortfall),
       p.repeatedKeysPerSecond};
    if(keys==7 && chart.layout.sides==1) {
        const auto m=v40::measure(chart,tempo);
        for(int i=0;i<v37::Skills;++i)x[24+i]=std::log1p(std::max(0.,m.raw[i]));
        x[32]=m.freshKeys/std::max(1.,m.keyHeads);x[33]=m.chordContacts/std::max(1.,m.keyHeads);
        x[34]=m.direct150/std::max(1.,m.keyHeads);x[35]=m.fatigueRms;
    }
    return x;
}
inline SelectionStats summarize(const DecodedChart& chart,const RadarTempo& timing) {
    SelectionStats result;
    const auto features=measure(chart,timing,result);
    if(!chart.notes.empty() && chart.layout.perSide==7 && chart.layout.sides==1) {
        result.easy=model::predict(features,0);result.hard=model::predict(features,1);
    }
    return result;
}
}

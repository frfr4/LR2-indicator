#pragma once
#include "radar.hpp"
#include <iterator>
#include <optional>
#include <limits>
namespace chart_radar {
// Score arrays keep their Axis IDs. The UI looks them up in spatial order.
inline constexpr std::array<Axis, Count> detailOrder{
    Density, Peak, Stair, Jack, Chord, Stamina, Scratch, Soflan
};
// Seven visible spokes. The eight-column on-disk score layout stays compatible.
inline constexpr std::array<Axis,7> visibleAxes{Density,Stair,Jack,Chord,Stamina,Scratch,Soflan};
inline constexpr std::array<Axis,7> radarClockwise{
    Density, Stair, Scratch, Soflan, Stamina, Jack, Chord
};

using RGB = std::array<int,3>;
using Shadow = std::optional<RGB>;
// Classify the same hundredths shown by the counters, including player averages.
inline long long displayCents(double score) {
    if (!(score>0.)) return 0;
    constexpr auto limit=std::numeric_limits<long long>::max();
    return score>=static_cast<double>(limit)/100. ? limit : std::llround(score*100.);
}
constexpr long long invertedRatingCents = 120000;
inline bool redRating(long long cents) { return cents>=90000 && cents<100000; }
inline bool boldRating(double score) {
    return displayCents(score)>=90000;
}
inline RGB ratingColor(double score) {
    struct Stop {long long cents; RGB ink;};
    static constexpr Stop stops[] = {
        {0,{255,255,255}}, {10000,{255,224,64}}, {20000,{255,159,65}}, {40000,{255,65,77}},
        {60000,{255,119,182}}, {77000,{187,119,255}}, {80000,{187,119,255}},
        {89999,{120,59,190}}
    };
    const long long cents = displayCents(score);
    if (cents >= invertedRatingCents) return {255,255,255};
    if (cents >= 100000) return {0,0,0};
    if (redRating(cents)) return {255,48,69};
    if (cents <= stops[0].cents) return stops[0].ink;
    for (std::size_t i=1; i<std::size(stops); ++i) {
        const auto& from=stops[i-1];
        const auto& to=stops[i];
        if (cents>to.cents) continue;
        const double t=static_cast<double>(cents-from.cents)/(to.cents-from.cents);
        RGB rgb{};
        for (std::size_t ch=0; ch<rgb.size(); ++ch)
            rgb[ch]=static_cast<int>(std::lround(from.ink[ch]+t*(to.ink[ch]-from.ink[ch])));
        return rgb;
    }
    return stops[std::size(stops)-1].ink;
}
inline Shadow ratingShadow(double score) {
    const auto cents=displayCents(score);
    if (cents>=invertedRatingCents) return RGB{0,0,0};
    if (cents>=100000) return RGB{255,255,255};
    if (redRating(cents)) return RGB{0,0,0};
    if (cents>=80000) return RGB{198,200,208};
    return std::nullopt;
}
enum class DetailBand { Standard, Red, Monochrome, Inverted };
inline DetailBand detailBand(double value) {
    const auto cents=displayCents(value);
    if (cents>=invertedRatingCents) return DetailBand::Inverted;
    if (cents>=100000) return DetailBand::Monochrome;
    if (redRating(cents)) return DetailBand::Red;
    return DetailBand::Standard;
}
inline int displayedShortfall(int original) {
    // Tables and all generations of the cache retain their original integer scale.
    return 2*std::clamp(original,0,50);
}
struct RadarView {
    Scores radii{};
    std::array<RGB, Count> labelColors{};
    RGB polygonColor{};
    double peak=0.;
};
inline RadarView makeView(const Scores& scores) {
    RadarView view;
    for (Axis axis:visibleAxes) {
        const double score=scores[axis];
        if (!std::isfinite(score)||score<0.)
            throw std::invalid_argument("radar score outside its display range");
        view.peak=std::max(view.peak,score);
    }
    view.polygonColor=ratingColor(view.peak);
    for (int i=0;i<Count;++i) {
        // At low difficulty preserve the shape at a readable size. Radius
        // is proportional to the visible score for every axis.
        const double visible=view.peak>0. && view.peak<200. ? 200.*(scores[i]/view.peak) : scores[i];
        view.radii[i]=visible/600.;
        view.labelColors[i]=ratingColor(scores[i]);
    }
    return view;
}
}

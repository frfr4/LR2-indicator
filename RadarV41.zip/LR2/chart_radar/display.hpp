#pragma once
#include "player_rating.hpp"
#include <cmath>
#include <cstdio>

namespace chart_radar {
// Coordinates inside the 540 x 850 select-skin element (FHD origin 703, 145).
struct Point { int x, y; };
struct Panel {
    static constexpr int w=540, h=850, x=703, y=145;
    static constexpr Point center{270,258};
    static constexpr double radius=113.;
    static constexpr int songRowTrim=3;
    static Point point(int spoke, double strength) {
        const double angle=spoke*(6.28318530717958647693/radarClockwise.size());
        return {center.x+static_cast<int>(std::lround(radius*strength*std::sin(angle))),
                center.y-static_cast<int>(std::lround(radius*strength*std::cos(angle)))};
    }
};
using Tips=std::array<Point,radarClockwise.size()>;
// Sample in final screen pixels. Each major-axis slice has at least one pixel.
// Both adjoining edges use exactly the same one-pixel endpoint.
template<class Plot>
void rasterEdge(Point a,Point b,double width,double taperPixels,Plot plot) {
    const bool vertical=std::abs(b.y-a.y)>std::abs(b.x-a.x);
    if (vertical) {std::swap(a.x,a.y);std::swap(b.x,b.y);}
    if (a.x>b.x) std::swap(a,b);
    const int steps=b.x-a.x, rise=b.y-a.y;
    if (!steps) {plot(vertical?a.y:a.x,vertical?a.x:a.y);return;}
    const double stepLength=std::hypot(steps,rise)/steps;
    const double fullWidth=std::max(1.,width*stepLength);
    for (int k=0;k<=steps;++k) {
        const int middle=a.y+int(std::lround(double(rise)*k/steps));
        const double fromEnd=std::min(k,steps-k)*stepLength;
        const double taper=std::min(1.,fromEnd/taperPixels);
        const int count=1+int(std::lround((fullWidth-1.)*taper));
        const int lower=middle-count/2;
        for (int y=lower;y<lower+count;++y) {
            if (vertical) plot(y,a.x+k);
            else plot(a.x+k,y);
        }
    }
}
template<class Canvas>
void drawPanel(Canvas& canvas, const Scores& target, bool player, double overall, double progress) {
    const auto view = makeView(target);
    canvas.back(player);
    Tips tip;
    for (size_t i=0;i<tip.size();++i) {
        const double r=view.radii[radarClockwise[i]];
        tip[i]=Panel::point(i,r*growth(progress));
    }
    auto face=view.polygonColor;
    if (displayCents(view.peak)<invertedRatingCents) {
        for (auto& c:face) c=static_cast<int>(std::lround(c*.49));
    }
    for (size_t i=0;i<tip.size();++i) canvas.triangle(Panel::center,tip[i],tip[(i+1)%tip.size()],face);
    for (size_t i=0;i<tip.size();++i) {
        const int next=(i+1)%tip.size();
        for (double r:{.50,.75}) canvas.line(Panel::point(i,r),Panel::point(next,r),{60,69,76});
        canvas.line(Panel::center,Panel::point(i,1.),{80,91,98});
        canvas.line(Panel::point(i,1.),Panel::point(next,1.),{122,136,144});
    }
    if (progress>0. && view.peak>0.) {
        const auto shadow=ratingShadow(view.peak);
        const bool red=redRating(displayCents(view.peak));
        if (shadow) {
            // Draw the entire halo first so it cannot cover an adjoining black edge.
            canvas.outline(tip,*shadow,red?7:5);
        }
        canvas.outline(tip,view.polygonColor,red?3:(shadow?2:1));
    }
    canvas.labels(player);
    // The rolling number crosses the same thresholds as its settled value.
    const auto drawCounter=[&](Point pos,double score,bool detail) {
        const double shown=counter(score,progress);
        canvas.number(pos,shown,detail);
    };
    if (player) drawCounter({387,567},overall,false);
    for (std::size_t i=0;i<visibleAxes.size();++i)
        drawCounter({387,599-(player?0:78+int(i+1)*Panel::songRowTrim)+static_cast<int>(std::lround(i*32.8))},target[visibleAxes[i]],true);
}
}

#pragma once
#include "presentation.hpp"
#include <algorithm>
#include <numeric>
#include <string>
#include <unordered_map>

namespace chart_radar {
struct Record {
    int clear, perfect, great, totalnotes;
};
inline double recordWeight(const Record& r) {
    if (r.clear < 2 || r.clear > 5 || r.totalnotes <= 0 || r.perfect < 0 || r.great < 0 ||
        static_cast<long long>(r.perfect) + r.great > r.totalnotes) return 0.;
    const auto ex = 2LL * r.perfect + r.great;
    const auto maxEx = 2LL * r.totalnotes;
    if (ex * 9 < maxEx * 5) return 0.; // C and below
    const double fraction = static_cast<double>(ex) / maxEx;
    const double rank = std::min(1.05, .20 + .90 * fraction);
    const double lamp = r.clear >= 4 ? 1.10 : r.clear == 3 ? 1.02 : 1.;
    return rank * lamp;
}
struct RatedChart {
    std::string hash;
    double value;
};
struct PlayerRating {
    std::array<std::vector<RatedChart>, Count> best;
    Scores axes{};
    double overall = 0.;
};
class PlayerSamples {
    // The SQLite reader presents one best record per chart hash.
    std::array<std::vector<RatedChart>, Count> best;
public:
    void add(const Scores& chart, const Record& record,const std::string& hash={}) {
        const double weight = recordWeight(record);
        if (weight == 0.) return;
        for (Axis axis : visibleAxes) {
            auto& top = best[axis];
            const double value = chart[axis] * weight;
            RatedChart entry{hash,value};
            const auto better=[](const RatedChart& a,const RatedChart& b) {
                return a.value==b.value ? a.hash<b.hash : a.value>b.value;
            };
            if (top.size()==10 && !better(entry,top.back())) continue;
            top.insert(std::upper_bound(top.begin(),top.end(),entry,better),std::move(entry));
            if (top.size() > 10) top.pop_back();
        }
    }
    PlayerRating finish() const {
        PlayerRating out;
        out.best=best;
        for (Axis axis : visibleAxes) {
            const auto& top = best[axis];
            if (!top.empty())
                out.axes[axis] = std::accumulate(top.begin(), top.end(), 0., [](double sum,const RatedChart& row){return sum+row.value;}) / top.size();
        }
        auto ranked = out.axes;
        std::sort(ranked.begin(), ranked.end(), std::greater<double>());
        out.overall = std::accumulate(ranked.begin(), ranked.begin()+5, 0.) / 5.;
        return out;
    }
};

// Elapsed time is measured against the selection-change event (monotonic clock).
// Re-selecting another non-chart entry preserves the current player display.
struct SelectionMotion {
    static constexpr int duration = 800;
    bool initialized = false, player = false;
    std::string chart;
    long long since = 0;
    void select(bool showPlayer, const std::string& hash, long long now) {
        if (initialized && player == showPlayer && (showPlayer || chart == hash)) return;
        initialized = true; player = showPlayer; chart = hash; since = now;
    }
    double progress(long long now) const {
        return std::clamp(static_cast<double>(now - since)/duration, 0., 1.);
    }
};
inline double growth(double t) { return t*t*(3.-2.*t); }
inline double counter(double target,double t) {
    const double remaining=1.-std::clamp(t,0.,1.);
    return target+std::max(180.,.40*target)*remaining*remaining;
}
}

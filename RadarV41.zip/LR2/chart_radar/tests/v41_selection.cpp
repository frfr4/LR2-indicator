#include "catalog.hpp"
#include "clear_style.hpp"
#include <iostream>
namespace fs=std::filesystem;
using namespace chart_radar;
int main(int argc,char** argv) {
    if(argc!=2)return 1;
    const fs::path base=argv[1];fs::create_directories(base);
    const auto chart=base/"probe.bms",db=base/"stats.sqlite";
    std::ofstream(chart)<<"#BPM 120\n#TOTAL 180\n#BPM01 240\n#STOP01 192\n#00111:0100\n#00116:0100\n#00108:00010000\n#00109:00010000\n#00211:0100\n#00451:01000100\n";
    auto parsed=RadarTempo{};auto c=decodeChart(chart,7,0,&parsed);auto stat=v41::summarize(c,parsed);
    // Beats 4, 8, 16 alone are active. The STOP and trailing LN endpoint add no taps.
    if(std::abs(stat.average-4.)>1.e-6 || !stat.easy || !stat.hard || !std::isfinite(*stat.hard))return 2;
    if(!std::isfinite(stat.maximum)||stat.maximum<stat.average)return 3;
    const std::string h(32,'a');auto missing=base/"missing";
    {ChartCatalog cc(missing.string(),db.string());if(!cc.resolve(h,chart.string(),7,true,true))return 4;
     auto row=cc.selectionStats(h,7);if(!row || row->easy!=stat.easy || row->hard!=stat.hard)return 5;}
    {ChartCatalog cc(missing.string(),db.string());auto row=cc.selectionStats(h,7);
     if(!row || row->average!=stat.average || row->maximum!=stat.maximum || row->easy!=stat.easy)return 6;
     if(cc.selectionStats(h,14))return 7;}
    auto same=[](v41::Ink a,v41::Ink b){return a.edge==b.edge && a.glow==b.glow;};
    if(!same(v41::ink(2,50.),v41::ink(2,125.)) || !same(v41::ink(0,28.),v41::ink(0,35.)))return 8;
    if(v41::ink(2,0.).glow || v41::ink(0,-1.02).glow || v41::ink(1,1.73).glow)return 9;
    if(v41::ink(3,25.).glow<=0 || v41::ink(3,25.).glow>=255)return 10;
    if(!same(v41::ink(2,50.),v41::ink(1,25.)) || same(v41::ink(1,26.5),v41::ink(1,28.)))return 11;
    std::cout<<"Verified timed notes, active beat density, independent predictions, cache reopening and ink stops.\n";
}

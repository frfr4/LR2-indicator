#include "../select_canvas.hpp"
#include <array>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <set>
#include <sstream>
#include <string>

using namespace chart_radar;

int main(int argc,char** argv) {
    if (argc!=2) return 2;
    const std::string backend=argv[1];
    const bool dx9=backend=="dx9";
    const bool software=backend=="software";
    const auto stage=std::filesystem::current_path();
    SetAlwaysRunFlag(TRUE);
    SetNotSoundFlag(TRUE);
    SetNotInputFlag(TRUE);
    SetWaitVSyncFlag(FALSE);
    SetWindowVisibleFlag(FALSE);
    ChangeWindowMode(TRUE);
    SetGraphMode(1920,1080,32);
    SetWindowSize(640,360);
    if (software) {
        SetUseSoftwareRenderModeFlag(TRUE);
    } else {
        SetUseDirect3DVersion(dx9?DX_DIRECT3D_9:DX_DIRECT3D_11);
    }
    if (DxLib_Init()<0) {
        std::cerr<<"Could not start "<<backend<<" renderer\n";
        return 77;
    }
    std::filesystem::current_path(stage);
    const auto out=stage.parent_path()/"native-frames";
    std::filesystem::create_directories(out);
    std::ofstream(out/(backend+".ready"))<<"Initialized";
    std::cout<<"Requested "<<backend<<", active DxLib graphics version "<<GetUseDirect3DVersion()<<'\n';
    SetDrawScreen(DX_SCREEN_BACK);
    SetDrawBlendMode(DX_BLENDMODE_ALPHA,255);
    SelectCanvas canvas;
    if (!canvas.load()) return 4;
    struct Scene { const char* name; std::array<double,8> details; };
    const Scene scenes[]={
        {"Acacia",{887.83,135.43,969.32,401.73,55.74,731.76,37.95,0.}},
        {"7colors",{96.98,239.48,154.31,929.22,999.,610.44,23.02,0.}},
        {"Fishpot",{955.49,248.41,642.,621.08,359.33,935.89,126.,0.}},
        {"Sumizome",{1742.52,3548.37,1729.61,2245.11,2004.17,415.10,1458.49,0.}},
        {"Orglariya",{1381.55,1174.57,1103.77,1572.46,1243.23,1389.32,29.86,0.}}
    };
    for (const auto& scene:scenes) {
        Scores scores{};
        for (size_t i=0;i<detailOrder.size();++i) scores[detailOrder[i]]=scene.details[i];
        DrawBox(0,0,1920,1080,GetColor(229,229,229),TRUE);
        drawPanel(canvas,scores,false,0.,1.);
        const std::string file=(out/(backend+"-"+scene.name+".png")).string();
        if (SaveDrawScreenToPNG(488,0,1500,720,file.c_str())<0) return 5;
    }
    // An arbitrarily large retired PEAK must not alter any displayed pixel.
    auto radarSample=[&](double peak) {
        Scores chart{};chart[Density]=500.;chart[Jack]=750.;chart[Peak]=peak;
        DrawBox(0,0,1920,1080,GetColor(229,229,229),TRUE);drawPanel(canvas,chart,false,0.,1.);
        std::vector<unsigned> result;
        for(int y=232;y<890;y+=5)for(int x=795;x<1160;x+=5)result.push_back(DxLib::GetPixel(x,y));
        return result;
    };
    if(radarSample(0.)!=radarSample(4200.))return 8;
    if(canvas.textures[9]<0)return 16;
    DrawBox(0,0,1920,1080,GetColor(18,21,25),TRUE);
    for(int row=0;row<4;++row)canvas.selectionRow(row,std::array<double,4>{26.5,28.,0.,50.}[row]);
    const auto counters=(out/(backend+"-clear-density.png")).string();
    if(SaveDrawScreenToPNG(836,870,1110,970,counters.c_str())<0)return 17;
    // Inspect only the numeric ink; the label and unit are neutral.
    for(int row=0;row<4;++row) {
        int colored=0,black=0,light=0;
        for(int y=874+25*row;y<890+25*row;++y)for(int x=row<2?1031:978;x<(row<2?1104:1035);++x) {
            int r,g,b;GetColor2(DxLib::GetPixel(x,y),&r,&g,&b);
            black+=std::max({r,g,b})<14;light+=std::min({r,g,b})>145;
            if(row==0)colored+=r>g+40 && b>g+25;
            if(row==1)colored+=b>r+20 && b>g+45;
            if(row==2)colored+=std::max({r,g,b})-std::min({r,g,b})>45;
            if(row==3)colored+=r>g+70 && r>b+60;
        }
        if(black<2 || (row==2?(light<3 || colored>0):colored<4))return 18+row;
    }
    if (canvas.textures[7]<0) return 9;
    const std::array<int,8> percentages{0,40,50,52,74,75,76,100};
    for (const int percent:percentages) {
        const bool spike=percent==0 || (percent>=52 && percent<=76);
        DrawBox(0,0,1920,1080,GetColor(18,21,25),TRUE);
        if (percent%2==0) canvas.chartTraits({spike,percent/2});
        else canvas.drawTraits(spike,percent); // Exact artwork sample from the design.
        const std::string file=(out/(backend+"-footer-"+std::to_string(percent)+".png")).string();
        if (SaveDrawScreenToPNG(836,970,1110,994,file.c_str())<0) return 10;
    }
    if (canvas.textures[8]<0) return 11;
    std::set<std::vector<unsigned>> valueImages;
    struct PoorCase { const char* hash; const char* name; int expected; };
    for (const PoorCase example : {
            PoorCase{"90709c02ee7092b30907df62ed3bed40","liberte",9000},
            PoorCase{"bc058266641750aad0114546563b6004","74",667},
            PoorCase{"7f66d4460d89ebe5e9281554d41a42d3","cherry",111},
            PoorCase{"b22f2d866ff6e8f62b7b95e9b7fa3a9e","going",0}}) {
        std::ifstream table(std::string(assetDir)+"charts-v40.tsv");
        std::string row, hash;
        Scores scores{};
        ChartTraits traits;
        int late=0,extra=-1;
        while (std::getline(table,row)) {
            std::istringstream in(row);
            if (!(in>>hash) || hash!=example.hash) continue;
            for (auto axis:detailOrder) in>>scores[axis];
            if (!(in>>late>>traits.recoveryShortfall>>extra)) return 12;
            traits.endSpike=late!=0;
            break;
        }
        if (extra!=example.expected) return 13;
        DrawBox(0,0,1920,1080,GetColor(18,21,25),TRUE);
        drawPanel(canvas,scores,false,0.,1.);
        canvas.chartTraits(traits);
        canvas.hardPoor(extra);
        std::vector<unsigned> pixels;
        for (int y=998;y<1015;y++) for (int x=1042;x<1103;x++) pixels.push_back(DxLib::GetPixel(x,y));
        if (!valueImages.insert(pixels).second) return 14;
        const auto file=(out/(backend+"-poor-"+example.name+".png")).string();
        if (SaveDrawScreenToPNG(835,969,1112,1020,file.c_str())<0) return 15;
    }
    DxLib_End();
    return 0;
}

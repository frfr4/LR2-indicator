#include "../display.hpp"
#include "../ratio_soflan.hpp"
#include "../upper_range.hpp"
#include "../phrase_radar.hpp"
#include <iostream>

int main() {
    using namespace chart_radar;
    {
        std::vector<Note> mixed;
        for (int i=0;i<160;++i) {
            double t=i*.33;
            mixed.push_back({t,t,0,0});
            mixed.push_back({t,t,2,0});
            mixed.push_back({t+.10,t+.10,0,0});
            if (i%3==0) mixed.push_back({t+.19,t+.19,0,0});
        }
        auto physical=phrases::measure(mixed);
        Scores original{};
        original.fill(150.);original[Peak]=510.;original[Soflan]=22.;original[Scratch]=81.;
        auto revised=phrases::adjust(original,physical);
        if (!physical.valid || physical.relaxed<physical.strict || revised[Scratch]!=81. ||
            revised[Soflan]!=22. || !(revised[Peak]<original[Peak]) || revised[Jack]<=0.) return 80;
        if (phrases::adjust(original,phrases::measure({}))!=original) return 81;
        for (double x:revised) if (!std::isfinite(x) || x<0.) return 82;
    }
    if (extraPoorCents(1669,180)!=667 || extraPoorCents(1689,233)!=111 ||
        extraPoorCents(2549,300)!=0 || extraPoorCents(1500,0)!=0 ||
        extraPoorCents(500,500)!=1000 || extraPoorCents(19,0)!=9000) return 32;
    // Four chart seconds across each 1% window. Two onsets one second apart
    // overlap for 3/400 of the chart, at half speed with two keys then one.
    RadarTempo tempo{{{160.,10},{80.,3},{999.,1}},{{0.,160.},{199.,80.},{206.,160.},{400.,999.}}};
    std::vector<Note> scroll{{0.,0.,0,0.},{200.,200.,0,0.},{200.,200.,1,0.},{201.,201.,2,0.},{400.,400.,2,0.}};
    const double expected=100.*std::sqrt(2.*2.*.25*.0075)/4.;
    if (std::abs(ratioSoflan(scroll,tempo)-expected)>1.e-9) return 30;
    tempo.tempos={{0.,160.},{400.,999.}};
    if (ratioSoflan(scroll,tempo)!=0.) return 31;
    Scores base{};
    base.fill(300.);
    Scores rates{}, previous=base;
    rates[Peak]=60.4245;
    if (upperRange(previous,rates)!=previous) return 5;
    rates[Peak]*=2.;
    auto high=upperRange(previous,rates);
    if (std::abs(high[Peak]-1200.)>.01) return 6;
    rates[Peak]*=2.;
    if (upperRange(previous,rates)[Peak]<=high[Peak]) return 7;
    previous[Jack]=4000.;
    auto mixed=upperRange(previous,rates);
    for (int i=0;i<Count;++i)
        if (i!=Peak && mixed[i]!=previous[i]) return 8;
    if (mixed[Peak]!=upperRange(base,rates)[Peak]) return 9;
    std::vector<Note> repeats;
    for (int i=0;i<800;++i) repeats.push_back({i*.0125,i*.0125,2,0.});
    auto jacks=analyze(repeats);
    if (jacks.raw[Stair]!=0. || jacks.raw[Chord]!=0.) return 10;

    Scores shape{};
    shape[Stair]=986.41; shape[Peak]=287.18; shape[Scratch]=36.33;
    const auto radii=makeView(shape).radii;
    const auto tip=Panel::point(1,radii[Stair]);
    if (tip.x!=415 || tip.y!=142) return 11;
    shape[Stair]=4000.;
    auto huge=makeView(shape).radii;
    if (Panel::point(1,huge[Stair]).x!=859) return 12;
    using Band=DetailBand;
    if (detailBand(899.99)!=Band::Standard || detailBand(900.)!=Band::Red ||
        detailBand(999.99)!=Band::Red || detailBand(1000.)!=Band::Monochrome ||
        detailBand(1199.99)!=Band::Monochrome || detailBand(1200.)!=Band::Inverted) return 13;
    for (int raw=0;raw<=100;++raw)
        if (displayedShortfall(raw)!=std::min(100,raw*2)) return 14;
    // Fishpot's DELAY is 29.84 degrees wide. Check every octant and both
    // endpoints, including steep edges and edges shorter than the taper.
    for (int direction:{-1,1}) for (bool vertical:{false,true})
        for (int width:{1,3,7}) for (int run:{0,1,4,88,104}) {
            Point a{75,90},b{75+direction*run,90+direction*(run/3)};
            if (vertical) {std::swap(a.x,a.y);std::swap(b.x,b.y);}
            int atStart=0,atEnd=0,total=0;
            bool stray=false;
            rasterEdge(a,b,width,14.,[&](int x,int y) {
                ++total;
                const int major=vertical?y:x;
                if (major==(vertical?a.y:a.x)) {++atStart;stray|=x!=a.x || y!=a.y;}
                if (major==(vertical?b.y:b.x)) {++atEnd;stray|=x!=b.x || y!=b.y;}
            });
            if (stray || atStart!=1 || atEnd!=1 || total<run+1) return 15;
        }
    std::cout << "Native radar, ratio SOF-LAN and display checks passed.\n";
}

// Included only by Main.cpp of OpenLR2, after DxLib, structure and sqlite declarations.
#pragma once
#include "catalog.hpp"
#include "select_canvas.hpp"
#include <chrono>
#include <future>
#include <optional>

namespace chart_radar {
template<class T> bool ready(std::future<T>& task) {
    return task.valid() && task.wait_for(std::chrono::seconds(0))==std::future_status::ready;
}
struct NativeSelector {
    ChartCatalog catalog{std::string(assetDir)+"charts-v26.tsv","LR2files/Database/OpenLR2-radar.db"};
    SelectCanvas canvas;
    std::unordered_map<std::string,int> tiers;
    NativeSelector() {
        std::ifstream file(std::string(assetDir)+"tiers.tsv");
        std::string key;
        int label;
        while (file>>key>>label) if (label>=0 && label<59) tiers.emplace(key,label);
    }
    SelectionMotion motion;
    std::string account,songs,requestedChart,failedChart;
    std::future<std::optional<Scores>> chartTask;
    std::optional<PlayerRating> profile;
    std::shared_ptr<std::atomic<bool>> cancel;
    std::future<PlayerRating> profileTask;
    unsigned generation=1, pending=0, published=0;
    long long retry=0,chartRetry=0;
    static long long nowMs() {
        return std::chrono::duration_cast<std::chrono::milliseconds>(
            std::chrono::steady_clock::now().time_since_epoch()).count();
    }
    ~NativeSelector() { if (cancel) *cancel=true; }
    void invalidate() {
        ++generation;retry=0;
        if (cancel) *cancel=true;
    }
    void prepare(game& g,sqlite3* db,bool wait) {
        const char* mainFile=sqlite3_db_filename(db,"main");
        const char* profileFile=g.is_starter?mainFile:sqlite3_db_filename(db,"scoredb");
        if (!mainFile || !profileFile) {profile.reset();account.clear();return;}
        if (account!=profileFile || songs!=mainFile) {
            invalidate(); profile.reset();motion.initialized=false;
            account=profileFile;songs=mainFile;
        }
        while (published!=generation && nowMs()>=retry) {
            if (!profileTask.valid()) {
                pending=generation;
                cancel=std::make_shared<std::atomic<bool>>(false);
                profileTask=std::async(std::launch::async,[this,score=account,song=songs,stop=cancel]{
                    return loadProfile(score,song,catalog,stop.get());
                });
            }
            if (!ready(profileTask) && !wait) return;
            while (profileTask.wait_for(std::chrono::milliseconds(10))!=std::future_status::ready) {
                if (ProcessMessage()!=0) {*cancel=true;return;}
            }
            try {
                auto result=profileTask.get();
                if (pending==generation) {profile=result;published=pending;}
            } catch (const std::exception& e) {
                if (pending==generation) {
                    retry=nowMs()+2000;
                    ErrorLogFmtAdd("Radar profile: %s\n",e.what());
                }
            }
        }
    }
    void draw(game& g,sqlite3* conn) {
        prepare(g,conn,false);
        const auto now=nowMs();
        const int n=g.sSelect.cur_song;
        if (ready(chartTask)) {
            try {if (!chartTask.get()) {failedChart=requestedChart;chartRetry=now+2000;}}
            catch(const std::exception&) {failedChart=requestedChart;chartRetry=now+2000;}
        }
        const auto* item=g.sSelect.bmsList && n>=0 && n<g.sSelect.bmsListCount ? &g.sSelect.bmsList[n]:nullptr;
        const bool song=item && (item->folderType==0 || item->folderType==5) && item->keymode>=5;
        std::string key=song && item->hash.c_str()?hashKey(item->hash.c_str()):"";
        std::optional<Scores> target;
        std::optional<int> poorExtra;
        std::optional<v41::SelectionStats> stats;
        if (song && !key.empty()) {
            target=catalog.find(key,item->keymode);
            poorExtra=catalog.poorExtra(key,item->keymode);
            stats=catalog.selectionStats(key,item->keymode);
            if ((!target || !poorExtra.has_value() || !stats) && !chartTask.valid() && (failedChart!=key || now>=chartRetry) && item->filepath.c_str()) {
                requestedChart=key;
                chartTask=std::async(std::launch::async,[this,key,mode=item->keymode,path=std::string(item->filepath.c_str())]{
                    return catalog.resolve(key,path,mode,true,true);
                });
            }
            if (!target && (failedChart==key || !item->filepath.c_str() || !*item->filepath.c_str()))
                target=catalog.fallback(key,item->keymode);
        } else if (!song && profile) target=profile->axes;
        if (!canvas.load()) return;
        canvas.sx=skinSizeX/1920.;canvas.sy=skinSizeY/1080.;
        int bm,op,r,green,b;
        GetDrawBlendMode(&bm,&op);GetDrawBright(&r,&green,&b);
        SetDrawBlendMode(DX_BLENDMODE_ALPHA,255);
        if (!target) { canvas.back(!song);canvas.labels(!song);motion.initialized=false; }
        else {
            motion.select(!song,key,now);
            drawPanel(canvas,*target,!song,(!song && profile)?profile->overall:0.,motion.progress(now));
            if (song) {
                if (auto info=catalog.traits(key,item->keymode)) {
                    canvas.chartTraits(*info);
                    if (poorExtra) canvas.hardPoor(*poorExtra);
                }
                const auto tag=tiers.find(key);
                if (tag!=tiers.end()) {
                    const double peak=makeView(*target).peak;
                    canvas.tier(tag->second,ratingColor(peak),ratingShadow(peak));
                }
            }
        }
        if(song) {
            canvas.selectionRow(0,stats?stats->easy:std::optional<double>{});
            canvas.selectionRow(1,stats?stats->hard:std::optional<double>{});
            canvas.selectionRow(2,stats?std::optional<double>(stats->average):std::nullopt);
            canvas.selectionRow(3,stats?std::optional<double>(stats->maximum):std::nullopt);
        }
        SetDrawBright(r,green,b);SetDrawBlendMode(bm,op);
    }
};
inline std::unique_ptr<NativeSelector>& radarSession() {
    static std::unique_ptr<NativeSelector> session;
    return session;
}
inline void prepareSelectRadar(game& g,sqlite3* db,bool wait) {
    auto& session=radarSession();
    if (!session) session=std::make_unique<NativeSelector>();
    session->prepare(g,db,wait);
}
inline void startSelectRadar(game& g,sqlite3* db) {
    if (g.cmd_directplay) return;
    const char* file=g.config.skin.skinFilePath[SKINTYPE_SELECT].c_str();
    if (!file || !*file) return;
    std::ifstream skin(std::filesystem::u8path(file),std::ios::binary);
    std::string line;
    while (std::getline(skin,line)) {
        if (line.rfind("#CHARTPLAYER_RADAR",0)==0) {
            prepareSelectRadar(g,db,false);
            return;
        }
    }
}
inline void radarScoreSaved(game& g,sqlite3* db) {
    if (auto& session=radarSession()) {
        session->invalidate();
        session->prepare(g,db,false);
    }
}
inline void drawSelectRadar(game& g,sqlite3* db) {
    auto& session=radarSession();
    if (g.procSelecter!=2 || g.procPhase!=1 || !g.skstruct.wmixRadar) {
        if (session) session->motion.initialized=false;
        return;
    }
    if (!session) prepareSelectRadar(g,db,false);
    session->draw(g,db);
}
}

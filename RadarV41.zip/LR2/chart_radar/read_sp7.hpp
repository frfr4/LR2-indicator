// Read a selection-time note and timing timeline; audio and graphic assets are not opened.
#pragma once
#include "radar.hpp"
#include <cctype>
#include <cstdlib>
#include <charconv>
#include <unordered_map>
#include <filesystem>
#include <fstream>
#include <numeric>
#include <limits>
#include <random>
#include <string_view>
#include <string>

namespace chart_radar {
namespace bms {
struct Position {
    int measure, numerator, denominator;
    bool operator<(const Position& b) const {
        if (measure!=b.measure) return measure<b.measure;
        return 1LL*numerator*b.denominator < 1LL*b.numerator*denominator;
    }
};
// The calibration corpus serialized its event timestamps to twelve decimals.
inline double eventValue(double v) {
    char out[64];
    const auto end=std::to_chars(out,out+sizeof(out),v,std::chars_format::fixed,12);
    if (end.ec!=std::errc{}) throw std::invalid_argument("timing outside supported range");
    double result{};
    if (std::from_chars(out,end.ptr,result).ec!=std::errc{}) throw std::invalid_argument("invalid timing");
    return result;
}
struct Layout {
    int perSide, sides, scratches;
    explicit Layout(int mode) {
        if (mode!=5 && mode!=7 && mode!=9 && mode!=10 && mode!=14)
            throw std::invalid_argument("unknown chart mode");
        sides=mode>=10 ? 2 : 1;
        perSide=mode/sides;
        scratches=mode==9 ? 0 : sides;
    }
    int lane(const std::string& channel) const {
        const int side=channel[0]=='2' || channel[0]=='6';
        if (channel[0]!='1' && channel[0]!='2' && channel[0]!='5' && channel[0]!='6') return -1;
        const char ch=channel[1];
        if (perSide==9) {
            const std::string map=side ? "-----2345" : "123458967";
            const auto slot=map.find(ch);
            return ch>='1' && ch<='9' && slot!=map.npos ? static_cast<int>(slot) : -1;
        }
        if (side>=sides) return -1;
        if (ch=='6') return sides*perSide+side;
        const auto key=std::string_view("1234589").find(ch);
        return key<static_cast<std::size_t>(perSide) ? side*perSide+static_cast<int>(key) : -1;
    }
};
inline void require(bool b) {
    if (!b) throw std::invalid_argument("unsupported or invalid chart");
}
inline double number(const std::string& s) {
    std::size_t n=0;
    double v=std::stod(s,&n);
    require(std::isfinite(v) && n==s.size());
    return v;
}
}
struct RadarTempo {
    std::unordered_map<double,int> mainVotes;
    std::vector<std::pair<double,double>> tempos;
    // Absolute musical beat and active tempo; STOP carries no playable beat time.
    std::vector<std::pair<double,double>> beatTempos;
};
struct DecodedChart {
    std::vector<Note> notes;
    std::vector<Change> changes;
    double total;
    bms::Layout layout;
    int judgeRank=2;
};
// As in the gameplay loader, a press inside an active hold on the same lane
// does not add a judgment. The decoder has already merged simultaneous heads.
inline int gaugeNoteCount(const DecodedChart& chart) {
    std::array<double, 18> occupiedUntil;
    occupiedUntil.fill(-std::numeric_limits<double>::infinity());
    int count = 0;
    for (const auto& n : chart.notes) {
        if (n.start <= occupiedUntil[n.lane]) continue;
        occupiedUntil[n.lane] = n.end;
        ++count;
    }
    return count;
}

inline DecodedChart decodeChart(const std::filesystem::path& path,int mode,unsigned seed=0,RadarTempo* timing=nullptr) {
    using namespace bms;
    Layout layout(mode);
    std::ifstream file(path,std::ios::binary);
    if (!file) throw std::runtime_error("cannot read chart");
    std::map<Position,std::map<std::string,std::string>> rows;
    std::map<int,double> lengths;
    std::map<std::string,double> bpms, stops, scrolls;
    double initial=0., gaugeTotal=0.;
    int judgeRank=2;
    std::string lnobj,line;
    int maximum=0;
    bool base62=false;
    std::mt19937 random(seed);
    std::vector<int> rolls;
    struct Branch {bool parent, matched, active;};
    std::vector<Branch> branches;
    auto active=[&]{return branches.empty() || branches.back().active;};
    auto upper=[](std::string value) {
        for (char& c:value) if (c>='a' && c<='z') c=static_cast<char>(c-'a'+'A');
        return value;
    };
    while (std::getline(file,line)) {
        if (line.compare(0,3,"\xef\xbb\xbf")==0) line.erase(0,3);
        auto start=line.find_first_not_of(" \t");
        if (start==line.npos || line[start]!='#') continue;
        line.erase(0,start);
        line.erase(line.find_last_not_of("\r\t ")+1);
        const auto split=line.find_first_of(" \t");
        const auto rawKey=line.substr(1,split==line.npos?line.npos:split-1);
        const auto k=upper(rawKey);
        const auto begin=split==line.npos ? line.npos : line.find_first_not_of(" \t",split);
        const std::string v=begin==line.npos ? "" : line.substr(begin);
        if (k=="RANDOM" || k=="SETRANDOM") {
            int n=std::stoi(v); require(n>0);
            rolls.push_back(k=="RANDOM" ? 1+static_cast<int>(random()%n) : n);
            continue;
        }
        if (k=="ENDRANDOM") { if (!rolls.empty()) rolls.pop_back(); continue; }
        if (k=="IF") {
            bool take=!rolls.empty() && rolls.back()==std::stoi(v);
            branches.push_back({active(),take,active() && take});continue;
        }
        if (k=="ELSEIF" || k=="ELSE") {
            if (!branches.empty()) {
                auto& b=branches.back();
                bool take=!b.matched && (k=="ELSE" || (!rolls.empty() && rolls.back()==std::stoi(v)));
                b.active=b.parent && take; b.matched|=take;
            }
            continue;
        }
        if (k=="ENDIF") {if (!branches.empty()) branches.pop_back();continue;}
        if (!active()) continue;
        if (line.size()>=7 && line[6]==':' && line.substr(1,3).find_first_not_of("0123456789")==line.npos) {
            const int m=std::stoi(line.substr(1,3));
            const auto ch=upper(line.substr(4,2));
            const auto pos=line.find_first_not_of(" \t",7);
            if (pos==line.npos) continue;
            const auto data=base62?line.substr(pos):upper(line.substr(pos));
            maximum=std::max(maximum,m);
            if (ch=="02") {lengths[m]=number(data);require(lengths[m]>=0.);continue;}
            const bool mine=timing && ch[0]=='D' && layout.lane("1"+ch.substr(1))>=0;
            if (!mine && ch!="03" && ch!="08" && ch!="09" && ch!="SC" && layout.lane(ch)<0) continue;
            require(data.size()<2000000); // The engine consumes complete two-character cells.
            const int slots=static_cast<int>(data.size()/2);
            for (int i=0;i<slots;++i) {
                auto token=data.substr(i*2,2);
                if (token!="00") rows[{m,i,slots}][ch]=std::move(token);
            }
        } else {
            if (k=="BASE") base62=(v=="62");
            if (k=="BPM") initial=number(v);
            if (k=="RANK") {
                const long value=std::strtol(v.c_str(),nullptr,10);
                judgeRank=(value>=0 && value<=3)?static_cast<int>(value):2;
            }
            if (k=="TOTAL") gaugeTotal=std::strtol(v.c_str(),nullptr,10);
            if (k=="LNOBJ") lnobj=base62 ? v : upper(v);
            const auto suffix=base62 ? rawKey : k;
            if (k.size()==5 && k.compare(0,3,"BPM")==0) bpms[suffix.substr(3)]=number(v);
            if (k.size()==6 && k.compare(0,4,"STOP")==0) stops[suffix.substr(4)]=number(v);
            if (k.size()==8 && k.compare(0,6,"SCROLL")==0) scrolls[suffix.substr(6)]=number(v);
        }
    }
    if (initial<=0.) {
        const auto first=rows.find({0,0,1});
        if (first!=rows.end()) {
            if (first->second.count("03")) initial=std::stoi(first->second.at("03"),nullptr,16);
            if (first->second.count("08")) initial=std::abs(bpms.at(first->second.at("08")));
        }
    }
    require(initial>0.);
    std::vector<double> measure(maximum+2);
    for (int i=0;i<=maximum;++i) measure[i+1]=measure[i]+4*(lengths.count(i)?lengths[i]:1.);
    std::vector<Note> notes;
    std::vector<Change> changes;
    std::array<int,16> head,hold; head.fill(-1);hold.fill(-1);
    if (timing) { timing->mainVotes.clear(); timing->tempos={{0.,initial}}; timing->beatTempos={{0.,initial}}; }
    double time=0.,bpm=initial,scroll=1.;
    bool backward=false;
    Position previous{0,0,1};
    for (const auto& [p,cells]:rows) {
        const auto length=[&](int i){return lengths.count(i)?4.*lengths.at(i):4.;};
        double beats;
        if (previous.measure==p.measure) {
            const auto num=1LL*p.numerator*previous.denominator-1LL*previous.numerator*p.denominator;
            beats=length(p.measure)*num/(1LL*p.denominator*previous.denominator);
        } else {
            beats=length(previous.measure)*(previous.denominator-previous.numerator)/previous.denominator+
                  (measure[p.measure]-measure[previous.measure+1])+length(p.measure)*p.numerator/p.denominator;
        }
        time+=beats*60./bpm;
        previous=p;
        const double old=bpm;
        const bool wasBackward=backward;

        if (cells.count("03")) bpm=std::stoi(cells.at("03"),nullptr,16);
        if (cells.count("08") && bpms.count(cells.at("08"))) {
            const double next=bpms.at(cells.at("08"));
            if (next!=0.) {bpm=std::abs(next);backward=next<0.;}
        }
        require(bpm>0.);
        if (timing && old!=bpm) timing->tempos.emplace_back(eventValue(time),bpm);
        const auto pause=cells.count("09") && stops.count(cells.at("09")) ? stops.at(cells.at("09"))*60./(48.*bpm):0.;
        require(pause>=0.);
        const double oldScroll=scroll;
        if (cells.count("SC")) scroll=scrolls.at(cells.at("SC"));
        if (old!=bpm || scroll!=oldScroll || backward!=wasBackward) {
            // Zero scroll freezes the visual lanes; note times still follow the BPM.
            const double ratio=bpm/old*std::max(std::abs(scroll),1./64.)/std::max(std::abs(oldScroll),1./64.);
            changes.push_back({time,ratio,0.,((scroll<0.)!=backward)!=((oldScroll<0.)!=wasBackward)});
        }
        if (pause) changes.push_back({time+pause,1.,pause});
        const double beat=measure[p.measure]+length(p.measure)*p.numerator/p.denominator;
        if (timing && old!=bpm) timing->beatTempos.emplace_back(beat,bpm);
        for (const auto& [ch,token]:cells) {
            if (timing && ch[0]=='D') { ++timing->mainVotes[bpm]; continue; }
            const int k=layout.lane(ch);
            if (k<0) continue;
            if (ch[0]=='5' || ch[0]=='6') {
                head[k]=-1;
                if (hold[k]>=0) { notes[hold[k]].end=time;hold[k]=-1; }
                else { if (timing) ++timing->mainVotes[bpm]; hold[k]=static_cast<int>(notes.size());notes.push_back({time,time,k,beat}); }
            } else if (token==lnobj && head[k]>=0) { notes[head[k]].end=time;head[k]=-1; }
            else { if (timing) ++timing->mainVotes[bpm]; head[k]=static_cast<int>(notes.size());notes.push_back({time,time,k,beat}); }
        }
        time+=pause;
    }
    require(std::all_of(hold.begin(),hold.end(),[](int i){return i==-1;}));
    for (auto& n:notes) { n.start=eventValue(n.start);n.end=eventValue(n.end); }
    // A simultaneous LN/tap (or two rows at a zero-length measure) is one physical key press.
    std::sort(notes.begin(),notes.end(),[](const Note& a,const Note& b) {
        return std::pair{a.start,a.lane}<std::pair{b.start,b.lane};
    });
    std::size_t written=0;
    for(const auto& n:notes) {
        if(written && notes[written-1].start==n.start && notes[written-1].lane==n.lane)
            notes[written-1].end=std::max(notes[written-1].end,n.end);
        else notes[written++]=n;
    }
    notes.resize(written);
    for (auto& c:changes) { c.time=eventValue(c.time);c.ratio=eventValue(c.ratio);c.stop=eventValue(c.stop); }
    return {std::move(notes),std::move(changes),gaugeTotal,layout,judgeRank};
}

inline Result measureChart(const std::filesystem::path& path,int mode,unsigned seed=0) {
    auto d=decodeChart(path,mode,seed);
    return analyze(std::move(d.notes),d.changes,d.layout.perSide,d.layout.sides,d.layout.scratches,d.total);
}
inline Scores readChart(const std::filesystem::path& path,int mode,unsigned seed=0) {return measureChart(path,mode,seed).scores;}
inline Scores readSP7(const std::filesystem::path& path) {return readChart(path,7);}
}

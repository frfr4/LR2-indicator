// Main.cpp owns the shared, active-player chart catalog. The scene calls this once before FlipScore.
#pragma once
#include "../HitTrail.h"
#include <cstring>

namespace chart_radar {
namespace results {
constexpr int width=540, height=643, listY=334;
struct Graphics {
    int tags=-1, digits=-1, font=-1;
    ImageFont* bitmapFont;
    explicit Graphics(ImageFont* skinFont=nullptr) : bitmapFont(skinFont) {
        const std::string dir="LR2files/Theme/KCOOL_WMIX_FHD/WMIX/result/";
        tags=LoadGraph((dir+"personal-axes.png").c_str());
        digits=LoadGraph((dir+"personal-digits.png").c_str());
        font=CreateFontToHandle("Meiryo UI",17,5,DX_FONTTYPE_ANTIALIASING);
    }
    ~Graphics() {
        for(int id : {tags,digits}) if(id>=0) DeleteGraph(id);
        if(font>=0) DeleteFontToHandle(font);
    }
    int length(const std::string& s) const {
        return font<0?GetDrawStringWidth(s.c_str(),int(s.size())):GetDrawStringWidthToHandle(s.c_str(),int(s.size()),font);
    }
    void text(int x,int y,std::string s,int maxW,unsigned color=0xebe3e3,bool right=false,int inkHeight=15) const {
        if(s.empty()) return;
        if(bitmapFont && bitmapFont->size>0) {
            auto chars=utf8_to_utf32(s);
            const auto available=[&](char32_t c) {
                auto it=bitmapFont->chars.find(c);
                return it!=bitmapFont->chars.end() && it->second.width>0;
            };
            if(!chars.empty() && available(U'.') && std::all_of(chars.begin(),chars.end(),available)) {
                // The WMIX small atlas has 26 px of ink and 12 px of top bearing per 48 px em.
                const double scale=inkHeight*48.0/(26.0*bitmapFont->size);
                const auto advance=[&](char32_t c){return bitmapFont->chars.at(c).width+bitmapFont->kerning;};
                int width=-bitmapFont->kerning;
                for(auto c:chars)width+=advance(c);
                if(width*scale>maxW) {
                    width+=3*advance(U'.');
                    while(!chars.empty() && width*scale>maxW) {
                        width-=advance(chars.back());chars.pop_back();
                        auto pos=s.size()-1;
                        while(pos && (static_cast<unsigned char>(s[pos])&0xc0)==0x80) --pos;
                        s.resize(pos);
                    }
                    s+="...";
                }
                CSTR value(int(s.size()+1));value=s.c_str();
                DSTdraw box{};
                box.x=right?x-std::lround(width*scale):x;
                box.y=y-std::lround(inkHeight*12.0/26.0);
                box.w=width+1;box.h=float(scale*bitmapFont->size);
                box.filter=DX_DRAWMODE_BILINEAR;box.blend=DX_BLENDMODE_ALPHA;box.a=255;
                box.r=(color>>16)&255;box.g=(color>>8)&255;box.b=color&255;
                const int previous=GetDrawMode();
                int fallback=font;
                LRDrawText(&fallback,&box,&value,bitmapFont);
                SetDrawMode(previous);SetDrawBright(255,255,255);
                return;
            }
        }
        if(length(s)>maxW) {
            while(!s.empty() && length(s+"...")>maxW) {
                auto pos=s.size()-1;
                while(pos && (static_cast<unsigned char>(s[pos])&0xc0)==0x80) --pos;
                s.resize(pos);
            }
            s+="...";
        }
        if(right) x-=length(s);
        if(font>=0) DrawStringToHandle(x,y,s.c_str(),color,font);
        else DrawString(x,y,s.c_str(),color);
    }
    void number(int right,int y,const std::string& s,int size=13) const {
        // Width table in pixels at the 14-pixel WMIX silver atlas size.
        constexpr char alphabet[]="0123456789.+-:%# ms";
        constexpr int advance[]={12,8,13,13,13,13,13,12,13,13,5,10,10,6,14,12,6,16,11};
        if(digits<0){text(right,y-2,s,140,0xe5dddd,true);return;}
        for(auto it=s.rbegin();it!=s.rend();++it) {
            const char* pos=std::strchr(alphabet,*it);
            if(!pos)continue;
            const int k=int(pos-alphabet);
            const int w=int(std::lround(advance[k]*size/14.));
            right-=w;
            if(*it!=' ') DrawRectExtendGraph(right,y,right+w,y+size,k*20,0,advance[k],14,digits,TRUE);
            --right;
        }
    }
};
inline std::string fixed(double value,int precision=2,bool sign=false) {
    char buf[48]; std::snprintf(buf,sizeof buf,sign?"%+.*f":"%.*f",precision,value); return buf;
}
inline void timing(const game& g,const Graphics& gfx) {
    constexpr int x0=25,x1=515,mid=170;
    const auto y=[](int offset){return 170+int(std::lround(std::clamp(offset,-200,200)*0.4));};
    constexpr int grid[]={0,0,0x4c2634,0x204233,0x534327,0x33404b};
    for(int grade=2;grade<=5;++grade) {
        int t=g.gameplay.player[0].judgetime[grade];
        if(t>0 && t<200) for(int sign:{-1,1}) DrawLine(x0,y(sign*t),x1,y(sign*t),grid[grade]);
    }
    DrawLine(x0,mid,x1,mid,0x766d73);
    double duration=std::max(1.,g.gameplay.song_runtime),avg=0.,m2=0.;
    constexpr int ink[]={0xff6d85,0xff6d85,0xff6d85,0x50d39a,0xffce56,0x94cfff};
    int count=0;
    for(const auto& p:hit_trail::history().snapshot()) {
        if(p.grade<0 || p.grade>5) continue;
        int x=x0+int(std::lround((x1-x0)*std::clamp(p.songMs/duration,0.,1.)));
        int row=y(p.grade==0?-200:p.offset);
        DrawBox(x-1,row-1,x+2,row+2,ink[p.grade],TRUE);
        if(p.grade!=0) {
            double d=p.offset-avg;avg+=d/(++count);m2+=d*(p.offset-avg);
        }
    }
    gfx.number(325,61,count?fixed(avg,1,true)+" ms":"--",14);
    gfx.number(509,61,count?fixed(std::sqrt(m2/count),1)+" ms":"--",14);
    for(int i=0;i<3;++i) {
        const int sec=int(duration*i/2000.);
        char clock[32];std::snprintf(clock,sizeof clock,"%d:%02d",sec/60,sec%60);
        gfx.number(i==0?59:i==1?289:515,298,clock);
    }
}
inline std::string trackTitle(sqlite3* db,const std::string& hash) {
    auto s=query(db,"SELECT title,subtitle FROM main.song WHERE hash IN (?1,upper(?1)) ORDER BY path LIMIT 1");
    sqlite3_bind_text(s.get(),1,hash.c_str(),-1,SQLITE_TRANSIENT);
    if(sqlite3_step(s.get())==SQLITE_ROW) {
        auto str=[&](int i){const auto* p=sqlite3_column_text(s.get(),i);return std::string(p?reinterpret_cast<const char*>(p):"");};
        std::string title=str(0), sub=str(1);
        if(!sub.empty())title+=" "+sub;
        if(!title.empty())return title;
    }
    static const auto titles=[]{
        std::unordered_map<std::string,std::string> values;
        std::ifstream stream("LR2files/Theme/KCOOL_WMIX_FHD/WMIX/result/personal-titles.tsv");
        std::string line;while(std::getline(stream,line)) if(line.size()>33 && line[32]=='\t')values.emplace(line.substr(0,32),line.substr(33));
        return values;
    }();
    auto i=titles.find(hash);
    return i==titles.end()?"Chart "+hash.substr(0,8):i->second;
}
inline void leaderboard(game& g,sqlite3* db,const Graphics& gfx) {
    const int n=g.sSelect.cur_song;
    if(!g.sSelect.bmsList || n<0 || n>=g.sSelect.bmsListCount || g.gameplay.isCourse) return;
    const auto& item=g.sSelect.bmsList[n];
    if(!item.hash.c_str())return;
    std::string hash=hashKey(item.hash.c_str());
    prepareSelectRadar(g,db,true);
    auto& session=*radarSession();
    auto chart=session.catalog.resolve(hash,item.filepath.c_str()?item.filepath.c_str():"",item.keymode);
    if(!chart) chart=session.catalog.fallback(hash,item.keymode);
    if(!chart) {
        gfx.text(30,listY+104,"Chart rating unavailable",460);
        gfx.number(510,listY+272,"--");
        return;
    }
    Axis axis=visibleAxes[0];
    for(auto a:visibleAxes)if((*chart)[a]>(*chart)[axis])axis=a;
    if(gfx.tags>=0)DrawRectGraph(29,listY+58,0,24*int(axis),170,20,gfx.tags,TRUE);
    else gfx.text(29,listY+55,names[axis],170);
    const auto& p=g.gameplay.player[0];
    const bool eligible=!g.gameplay.isAutoplay && !g.gameplay.isNosave && g.gameplay.replay.status!=2
        && g.config.play.battle!=OPTION_BATTLE_BATTLE && !g.config.play.m_isLunaris;
    const double current=eligible?(*chart)[axis]*recordWeight({p.clearType,p.judgecount[5],p.judgecount[4],p.totalnotes}):0.;
    if(!session.profile || session.published!=session.generation) {
        gfx.text(30,listY+104,"Player scores unavailable",460);
        gfx.number(510,listY+272,fixed(current));
        return;
    }
    auto rows=session.profile->best[axis];
    auto old=std::find_if(rows.begin(),rows.end(),[&](const RatedChart& r){return r.hash==hash;});
    bool personal=current>0 && (old==rows.end() || displayCents(current)>=displayCents(old->value));
    if(personal) {
        if(old==rows.end())rows.push_back({hash,current});else old->value=std::max(old->value,current);
        std::sort(rows.begin(),rows.end(),[](const RatedChart& a,const RatedChart& b){return a.value!=b.value?a.value>b.value:a.hash<b.hash;});
        if(rows.size()>10)rows.resize(10);
    }
    double avg=0.;for(auto& r:rows)avg+=r.value;
    gfx.number(511,listY+59,fixed(rows.empty()?0.:avg/rows.size()),14);
    gfx.text(414,listY+60,std::string("PLAYER ")+names[axis],170,0xd2c7cb,true,12);
    int position=0;
    for(int i=0;i<5;++i) {
        int y=listY+87+33*i;
        if(i<int(rows.size()) && rows[i].value>0) {
            if(personal && rows[i].hash==hash) {
                position=i+1;DrawBox(23,y+2,516,y+30,0x442728,TRUE);DrawLine(23,y+3,23,y+29,0xe9b18f);
            }
            gfx.number(49,y+10,"0"+std::to_string(i+1),12);
            gfx.number(138,y+10,fixed(rows[i].value));
            gfx.text(174,y+9,trackTitle(db,rows[i].hash),336);
        } else {
            gfx.number(49,y+10,"0"+std::to_string(i+1),12);
            gfx.text(174,y+9,"--",100,0xab999f);
        }
    }
    if(position) {
        gfx.number(175,listY+272,"#0"+std::to_string(position));
        const char* lamps[]={"","","EASY CLEAR","NORMAL CLEAR","HARD CLEAR","FULL COMBO"};
        double rate=100.*(2.*p.judgecount[5]+p.judgecount[4])/(2.*p.totalnotes);
        gfx.text(510,listY+272,std::string(lamps[p.clearType])+"   "+fixed(rate)+"%",265,0xdfc9bc,true,13);
    } else {
        gfx.text(141,listY+271,trackTitle(db,hash),265,0xebe3e3,false,14);
        gfx.number(510,listY+272,fixed(current));
    }
}
}
void installResultStack(game& g, sqlite3* db) {
    auto& sk=g.skstruct;
    if(sk.resultStackIndex<0 || sk.resultStackIndex>=sk.image.srcSize)return;
    auto& src=sk.image.src[sk.resultStackIndex];
    if(src.graphcount!=1 || !src.grHandles)return;
    results::Graphics gfx(&sk.ImageFonts[2]);
    int screen=GetDrawScreen(),blend,alpha,r,green,b;
    GetDrawBlendMode(&blend,&alpha);GetDrawBright(&r,&green,&b);
    int plot=MakeScreen(results::width,results::height,TRUE);
    if(plot<0)return;
    FillGraph(plot,0,0,0,0);
    if(SetDrawScreen(plot)<0){DeleteGraph(plot);return;}
    SetDrawBright(255,255,255);
    SetDrawBlendMode(DX_BLENDMODE_ALPHA,255);
    results::timing(g,gfx);
    try {results::leaderboard(g,db,gfx);}
    catch(const std::exception& e){ErrorLogFmtAdd("Result ranking: %s\n",e.what());gfx.text(32,results::listY+105,"Player scores unavailable",460);}
    SetDrawScreen(screen);SetDrawBright(r,green,b);SetDrawBlendMode(blend,alpha);
    if(src.grHandles[0]>=0)DeleteGraph(src.grHandles[0]);
    src.grHandles[0]=plot;
}
}

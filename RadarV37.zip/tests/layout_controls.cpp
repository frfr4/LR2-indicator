#include "v37_scores.hpp"
#include <iostream>
#include <iomanip>
using namespace chart_radar;
int main(){
    const auto m0=v37::maskMap("1234567"),m1=v37::maskMap("2461357"),m2=v37::maskMap("5761324");
    if(m0[1]!=1 || m1[1]!=8 || m2[1]!=8 || m1[2]!=1 || m2[16]!=1) return 2;
    for(int pattern=0;pattern<13;++pattern) {
        DecodedChart c{{},{},400.,bms::Layout(7)};
        RadarTempo tempo;tempo.tempos={{0.,150.}};tempo.mainVotes[150.]=1;
        unsigned rng=37324;int i=0;
        for(i=0;i<960;++i) {
            double t=.125*i;unsigned mask=0;
            rng=(1664525u*rng+1013904223u);
            switch(pattern){
            case 0:mask=1u<<(i%7);break;
            case 1:mask=1u<<((3*i)%7);break;
            case 2:mask=1u<<((rng>>8)%7);break;
            case 3:mask=1;break;
            case 4:mask=i%2?42:85;break;
            case 5:mask=128;break;
            case 6:mask=(1u<<(i%7))|(1u<<((i+3)%7));break;
            case 7:mask=1u<<(i%7);if(i==270){c.changes.push_back({t,.25,0.,false});tempo.tempos.push_back({t,37.5});}if(i==540){c.changes.push_back({t,4.,0.,false});tempo.tempos.push_back({t,150.});}break;
            case 8:break;
            case 9:mask=i==400?15:0;break;
            case 10:mask=1u<<(i%2);break;
            case 11:mask=(i%7)?1u<<((rng>>8)%7):15; if(i%4==2)t-=.04;break;
            case 12:mask=(i%4==0?3:1)<<(i%5);if(i%3==1)t-=.04;break;
            }
            for(int k=0;k<8;++k)if(mask&(1u<<k))c.notes.push_back({t,t,k,t*2.5});
        }
        auto m=v37::measure(c,tempo);auto r=v37::rating(m);
        if((pattern==3||pattern==5||pattern==8||pattern==9||pattern==10)&&r.axes[v37::Delay]!=0)return 3;
        if(pattern!=7&&r.axes[v37::Reading]!=0)return 4;
        if(pattern==7&&r.axes[v37::Reading]<=0)return 5;
        if(pattern==5&&(r.axes[v37::Deck]<=0||r.axes[v37::Chords]!=0))return 6;
        std::cout<<pattern;
        for(double a:r.axes)std::cout<<' '<<int(std::round(a));
        for(int l=0;l<4;++l)std::cout<<' '<<v37::dose(m.summary[l][v37::Delay]);
        std::cout<<'\n';
    }
}

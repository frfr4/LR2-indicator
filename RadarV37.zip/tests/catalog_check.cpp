#include "catalog.hpp"
#include <fstream>
#include <iostream>
#include <sstream>
using namespace chart_radar;
int main(int argc,char** argv) {
    if(argc!=7)return 2;
    const std::filesystem::path assets=argv[1];
    ChartCatalog bundled((assets/"charts.tsv").string());
    std::ifstream table(assets/"charts-v37.tsv");
    std::string line,hash;
    unsigned count=0;
    while(std::getline(table,line)) {
        std::istringstream in(line);in>>hash;auto scores=bundled.find(hash);
        if(!scores)return 3;
        for(auto axis:detailOrder) {
            double expected;if(!(in>>expected)||displayCents((*scores)[axis])!=displayCents(expected))return 4;
        }
        ++count;
    }
    if(count!=1954)return 5;
    const std::string fixtureHash=argv[3];
    Scores expected{};std::ifstream reference(argv[4]);
    for(auto a:detailOrder)if(!(reference>>expected[a]))return 6;
    for(int pass=0;pass<2;++pass) {
        ChartCatalog dynamic(argv[5],argv[6]);
        auto got=pass?dynamic.find(fixtureHash):dynamic.resolve(fixtureHash,argv[2],7,true);
        if(!got)return 7;
        for(auto a:detailOrder)if(displayCents((*got)[a])!=displayCents(expected[a]))return 8;
    }
    std::cout<<count<<" bundled charts; new chart matches the reference on all 8 axes before and after reopening the cache.\n";
}


add_executable(OpenLR2V37Controls EXCLUDE_FROM_ALL LR2/chart_radar/tests/layout_controls.cpp)
add_executable(OpenLR2V37Catalog EXCLUDE_FROM_ALL LR2/chart_radar/tests/catalog_check.cpp)
foreach(t OpenLR2V37Controls OpenLR2V37Catalog)
    target_compile_features(${t} PRIVATE cxx_std_17)
    target_compile_definitions(${t} PRIVATE NOMINMAX WIN32_LEAN_AND_MEAN)
    target_include_directories(${t} PRIVATE LR2/chart_radar)
    target_link_libraries(${t} PRIVATE SQLite)
endforeach()

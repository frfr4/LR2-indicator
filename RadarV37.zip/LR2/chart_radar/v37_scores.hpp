#pragma once
#include "v37_measure.hpp"
#include "v37_parameters.hpp"
namespace chart_radar::v37 {
struct Rating { Eight axes{}; double hard=0.; };
inline double dose(const std::array<double,summaryCount>& s) {
    return std::cbrt(s[0]*s[5]*(s[2]+s[4])*.5);
}
inline double ruler(double h) {
    if(h<3.)return 100.*std::exp((h-3.)/3.);
    if(h<=5.)return 100.+50.*(h-3.);
    if(h<=23.)return 200.+(500./18.)*(h-5.);
    return 700.+50.*(h-23.);
}
inline double physicalBase(double e) {
    namespace p=parameters;
    constexpr auto count=std::size(p::knots);
    if(e>p::knots[count-1])return p::values[count-1]+(e-p::knots[count-1])*
      (p::values[count-1]-p::values[count-3])/std::max(.0001,p::knots[count-1]-p::knots[count-3]);
    if(e<=p::knots[0])return p::values[0];
    const auto i=std::lower_bound(p::knots,p::knots+count,e)-p::knots;
    return p::values[i-1]+(e-p::knots[i-1])*(p::values[i]-p::values[i-1])/(p::knots[i]-p::knots[i-1]);
}
inline Rating rating(const Measurement& m) {
    namespace p=parameters;
    std::array<double,72> features{};std::size_t k=0;Eight strength{},variation{};
    for(int a=0;a<Skills;++a){
        const auto& s=m.summary[0][a];strength[a]=dose(s)/p::ref[a];
        for(double value:s)features[k++]=value;
        std::array<double,3> v{};
        for(int l=0;l<3;++l)v[l]=dose(m.summary[l+1][a])/p::ref[a];
        const auto bounds=std::minmax_element(v.begin(),v.end());
        variation[a]=*bounds.second-*bounds.first;
    }
    for(double value:m.context)features[k++]=value;
    auto sorted=strength;std::sort(sorted.begin(),sorted.end(),std::greater<double>());
    constexpr double ranked[]={1.,.40,.22,.12};double burden=0.;
    for(int i=0;i<4;++i){features[k++]=sorted[i];burden+=sorted[i]*sorted[i]*ranked[i];}
    for(double value:variation)features[k++]=value;
    double learnt=p::bias,nearest=std::numeric_limits<double>::infinity();
    for(std::size_t i=0;i<features.size();++i){
        double l=std::log1p(std::max(0.,features[i]));
        features[i]=2.5*std::asinh((l-p::centre[i])/(2.5*p::spread[i]));
        learnt+=features[i]*p::coef[i];
    }
    for(std::size_t i=0;i<std::size(p::weights);++i){
        double dist=0.;
        for(std::size_t j=0;j<features.size();++j){
            double d=features[j]-p::examples[i][j];dist+=d*d;
        }
        dist/=features.size();nearest=std::min(nearest,dist);
        learnt+=p::weights[i]*std::exp(-dist/(2*p::width*p::width));
    }
    double phys=physicalBase(std::log1p(std::sqrt(burden)));
    Rating out;out.hard=phys+std::exp(-nearest/p::locality)*(learnt-phys);
    if(sorted[0]>0.){
        const double factor=ruler(out.hard)*std::min(1.,m.context[1]/32.)/sorted[0];
        for(int a=0;a<Skills;++a)out.axes[a]=std::round(strength[a]*factor*100.)/100.;
    }
    return out;
}
inline Scores catalogScores(const DecodedChart& chart,const RadarTempo& timing) {
    auto out=rating(measure(chart,timing));Scores result{};
    constexpr Axis slots[]{Density,Peak,Stair,Jack,Chord,Stamina,Scratch,Soflan};
    for(int i=0;i<Skills;++i)result[slots[i]]=out.axes[i];
    return result;
}
}

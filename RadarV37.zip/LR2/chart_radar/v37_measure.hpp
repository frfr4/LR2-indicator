// 1P SP7 comparison of three displayed OpenLR2 layouts.
#pragma once
#include "read_sp7.hpp"
#include <bitset>
#include <numeric>
namespace chart_radar::v37 {
enum Skill { Notes, Burst, Delay, Repeat, Chords, Endurance, Deck, Reading, Skills };
using Eight=std::array<double,Skills>;
constexpr int windows=161,summaryCount=6,layouts=3,metrics=9;
constexpr std::array<const char*,layouts> displayLayouts{"1234567","2461357","5761324"};
constexpr std::array<double,4> widths{.0075,.025,.08,.20};
inline int pop(unsigned mask) {return static_cast<int>(std::bitset<8>(mask).count());}
inline double med(double a,double b,double c){return std::max(std::min(a,b),std::min(std::max(a,b),c));}
inline double closeness(double dt,double scale){return scale/(scale+std::max(0.,dt));}
inline double gm(double a,double b){return std::sqrt(std::max(0.,a*b));}
struct Frame {double t,beat,read; unsigned keys,holds; bool scratch;};
struct Passage {double start=0.,end=0.;std::array<int,metrics> counts{};std::array<double,3> load{};};
using Summaries=std::array<std::array<double,summaryCount>,Skills>;
struct Measurement {std::array<Summaries,4> summary{};std::array<Passage,Skills> evidence{};
    std::array<double,12> context{};double main=0.;};
inline std::array<unsigned,128> maskMap(const char* layout){
    std::array<unsigned,128> result{};
    for(unsigned mask=0;mask<128;++mask)for(int dst=0;dst<7;++dst)
        if(mask & (1u<<(layout[dst]-'1'))) result[mask]|=1u<<dst;
    return result;
}
inline std::vector<Frame> timeline(const DecodedChart& c,const RadarTempo& tempo,double& main){
    std::vector<Frame> rows;if(c.notes.empty()||tempo.tempos.empty())return rows;
    const double stopWindow=std::max(1.e-9,(c.notes.back().start-c.notes.front().start)*widths[0]);
    int votes=-1;for(auto item:tempo.mainVotes)
        if(item.second>votes || (item.second==votes && item.first>main)) {votes=item.second;main=item.first;}
    if(main<=0.)main=tempo.tempos.front().second;
    std::array<double,7> held{};held.fill(-1.e20);
    size_t ti=0,ci=0;double speed=1.,lastPause=-1.e20;bool reverse=false;
    for(size_t i=0;i<c.notes.size();){
        const double t=c.notes[i].start;
        while(ti+1<tempo.tempos.size()&&tempo.tempos[ti+1].first<=t+1.e-9)++ti;
        while(ci<c.changes.size()&&c.changes[ci].time<=t+1.e-9){
            const auto& ch=c.changes[ci++];speed*=ch.ratio;reverse^=ch.reversal;if(ch.stop>0.)lastPause=ch.time;
        }
        unsigned keys=0,busy=0;bool sc=false;
        for(int k=0;k<7;++k)if(held[k]>t+1.e-9)busy|=1u<<k;
        do{const auto n=c.notes[i++];if(n.lane==7)sc=true;else if(n.lane>=0&&n.lane<7){
            keys|=1u<<n.lane;held[n.lane]=std::max(held[n.lane],n.end);}
        }while(i<c.notes.size()&&c.notes[i].start<=t+.0000005);
        const double ratio=std::max(1.e-8,tempo.tempos.front().second*speed/main);
        const double read=std::min(8.,std::abs(std::log2(ratio)))+(reverse?1.:0.)+
            (lastPause> -1.e10 ? std::exp(-std::max(0.,t-lastPause)/stopWindow) : 0.);
        rows.push_back({t-c.notes.front().start,60./tempo.tempos[ti].second,read,keys,busy,sc});
    }
    return rows;
}
// Distinct triples in one hand. Stationary chord fingers and trills on two keys
// do not provide the moving three-finger voice measured here.
inline double fingerTriples(unsigned a,unsigned b,unsigned c,double& turns) {
    const unsigned ab=a&~b,bc=b&~c,ca=c&~b;
    double steps=0.;turns=0.;
    for(int j=0;j<7;++j)if(bc&(1u<<j))
        for(int i=std::max(0,j-2);i<=std::min(6,j+2);++i)if(ab&(1u<<i))
            for(int k=std::max(0,j-2);k<=std::min(6,j+2);++k)if(i!=k&&(ca&(1u<<k))){
                const double w=1./std::sqrt(double(std::abs(i-j)*std::abs(k-j)));
                if((j-i)*(k-j)>0)steps+=w;else turns+=w;
            }
    const double denom=std::max(1.,std::sqrt(double(pop(a)*pop(b)*pop(c))));
    turns/=denom;return steps/denom;
}
struct Hand {
    unsigned prev=0,back=0;double t=-1.e10,prior=-1.e10;
    struct Gesture {unsigned a=0,b=0,c=0;double gap=0.;};
    std::array<Gesture,16> recent{};std::size_t cursor=0;
    double predictability(unsigned next,double gap) {
        double repeats=0.;
        for(const auto& g:recent)if(g.a==back && g.b==prev && g.c==next && g.gap>0.)
            repeats+=std::min(g.gap,gap)/std::max(g.gap,gap);
        recent[cursor]={back,prev,next,gap};cursor=(cursor+1)%recent.size();
        return .45+.55/(1.+repeats);
    }
};
using Grid=std::array<Eight,windows>;
using Counter=std::array<int,metrics>;
struct Intervals {std::array<std::array<std::pair<int,int>,windows>,4> slots{};};
inline Intervals intervals(const std::vector<Frame>& rows,double T){
    Intervals ranges;
    for(int w=0;w<4;++w){int lo=0,hi=0;const double span=T*widths[w];
        for(int j=0;j<windows;++j){
            const double left=std::clamp(T*(j+.5)/windows-.5*span,0.,T-span);
            while(lo<int(rows.size())&&rows[lo].t<left-1.e-9)++lo;
            while(hi<int(rows.size())&&rows[hi].t<=left+span+1.e-9)++hi;
            ranges.slots[w][j]={lo,hi};
        }
    }
    return ranges;
}
struct LayoutData {Grid local{};std::vector<Counter> counts;};
inline LayoutData play(const std::vector<Frame>& rows,const Intervals& ranges,int layout,double T){
    const auto mapping=maskMap(displayLayouts[layout]);
    const int n=rows.size();LayoutData data;data.counts.resize(n+1);
    std::vector<Eight> prefix(n+1);std::vector<int> grips;
    std::array<std::vector<int>,7> laneRows;
    for(int i=0;i<n;++i){const unsigned k=mapping[rows[i].keys];if(pop(k)>=2)grips.push_back(i);
        for(int f=0;f<7;++f)if(k&(1u<<f))laneRows[f].push_back(i);
    }
    std::array<size_t,7> loc{};std::array<Hand,2> hands{};unsigned prev=0;
    double lastDeck=-1.e10;size_t gi=0;
    for(int i=0;i<n;++i){
        const auto& r=rows[i];const unsigned k=mapping[r.keys],held=mapping[r.holds];
        const int w=pop(k),l=pop(k&7u),rt=pop(k&120u),shared=pop(k&prev);
        const double cadence=w?(1.-double(shared)/std::max(w,pop(prev))):0.;
        double move=0.,technical=0.;int handRuns=0;
        for(int side=0;side<2;++side){
            const unsigned cur=k&(side==0?7u:120u);if(!cur)continue;
            auto& hand=hands[side];const double gap=r.t-hand.t;
            const int width=pop(cur);double turns=0.;
            const double steps=fingerTriples(hand.back,hand.prev,cur,turns);
            // The slower interval bounds a playable triple. Note speed and changes
            // of rhythm contribute only in a moving three-finger sequence.
            const double prevGap=hand.t-hand.prior;
            const double hz=1./(.02+std::max(gap,prevGap));
            const double fine=std::log1p(r.beat/(4.*(.012+std::max(gap,prevGap))));
            const double uneven=std::abs(gap-prevGap)/std::max(.01,gap+prevGap);
            // A repeated pair of chord shapes alone does not identify a traveling finger.
            const bool distinguishable=hand.back!=cur;
            const double variation=hand.predictability(cur,gap);
            const double voice=distinguishable?(steps+turns*(1.+uneven))*hz*hz*fine*variation:0.;
            technical+=voice;
            handRuns+=distinguishable && (steps+turns>0.);
            move+=closeness(gap,.14)*(1.+.22*std::max(0,width-1)+.16*pop(held&(side==0?7u:120u)));
            hand.back=hand.prev;hand.prev=cur;hand.prior=hand.t;hand.t=r.t;
        }
        double rep=0.;int fast=0,shortPairs=0;
        for(int lane=0;lane<7;++lane)if(k&(1u<<lane)){
            auto& p=loc[lane];auto& v=laneRows[lane];
            if(p){
                const double gap=r.t-rows[v[p-1]].t;
                const double before=p>1?rows[v[p-1]].t-rows[v[p-2]].t:1.e5;
                const double after=p+1<v.size()?rows[v[p+1]].t-r.t:1.e5;
                const double iso=std::clamp(std::log2(std::max(1.,std::min(before,after)/std::max(.001,gap))),0.,2.);
                const double f=closeness(gap,.14);
                const int neighbours=pop(k&(lane<3?7u:120u))-1;
                rep+=f*f*f*(1.+.55*iso)*(1.+.18*neighbours+.11*r.scratch*(lane<3));
                fast+=gap<=.15+1.e-9;shortPairs+=gap<=.225&&std::min(before,after)>1.5*gap;
            }++p;
        }
        double chord=0.;
        if(w>=2){
            chord=w-1.+.18*(w-1)*(w-2)+.32*(std::max(0,l-1)+std::max(0,rt-1));
            if(gi){const auto& old=rows[grips[gi-1]];const unsigned former=mapping[old.keys];
                chord+=(std::min(w,pop(former))-pop(k&former))*closeness(r.t-old.t,.18);}
            ++gi;
        }else if(w && gi && gi<grips.size()){
            auto edge=[&](int j){const unsigned g=mapping[rows[j].keys],side=l?7u:120u;
                return (pop(g)-1.+pop(g&side))*(1.+((g&k)?1.:0.))*std::pow(closeness(std::abs(rows[j].t-r.t),.11),2);};
            chord=gm(edge(grips[gi-1]),edge(grips[gi]));
        }
        const double press=w+.18*std::max(0,std::max(l,rt)-1)+.15*pop(held)*(w>0);
        const double deck=r.scratch?(1.+.12*w+.42*l+closeness(r.t-lastDeck,.15)):0.;
        const double reading=r.read*(w+.18*std::max(l,rt)+int(r.scratch));
        const Eight inc{w?(.45+.55*cadence+.17*std::max(0,w-1)+.28*move):0.,
            press,technical,rep,chord,press+.22*move+.15*deck,deck,reading};
        const Counter hits{w,w>0,w>=2,w>=4,int(r.scratch),fast,shortPairs,handRuns,r.read>1.e-6};
        for(int a=0;a<Skills;++a)prefix[i+1][a]=prefix[i][a]+inc[a];
        for(int j=0;j<metrics;++j)data.counts[i+1][j]=data.counts[i][j]+hits[j];
        if(k)prev=k;if(r.scratch)lastDeck=r.t;
    }
    for(int j=0;j<windows;++j)for(int a=0;a<Skills;++a){
        std::array<double,4> rate{};
        for(int w=0;w<4;++w){auto [l,h]=ranges.slots[w][j];rate[w]=(prefix[h][a]-prefix[l][a])/(T*widths[w]);}
        const auto [x,y,z,b]=rate;
        if(a==Burst)data.local[j][a]=gm(x,y)*(.25+std::max(0.,x-b)/std::max(1.,x));
        else if(a==Endurance)data.local[j][a]=gm(z,b)*std::log1p(T/25.);
        else data.local[j][a]=std::cbrt(x*y*z);
    }
    return data;
}
inline void summarize(const Grid& grid,Summaries& dest){
    for(int a=0;a<Skills;++a){
        std::array<double,windows> s{};for(int i=0;i<windows;++i)s[i]=grid[i][a];
        std::sort(s.begin(),s.end());const double avg=std::accumulate(s.begin(),s.end(),0.)/windows;
        const double rms=std::sqrt(std::inner_product(s.begin(),s.end(),s.begin(),0.)/windows);
        dest[a]={s.back(),s[152],s[128],s[80],avg,rms};
    }
}
inline Measurement measure(const DecodedChart& c,const RadarTempo& tempo){
    Measurement m;auto rows=timeline(c,tempo,m.main);
    if(rows.size()<2||rows.back().t<=0.)return m;
    const double T=rows.back().t;const auto ranges=intervals(rows,T);
    std::array<LayoutData,3> per;
    for(int k=0;k<3;++k){per[k]=play(rows,ranges,k,T);summarize(per[k].local,m.summary[k+1]);}
    Grid common{};
    for(int a=0;a<Skills;++a){
        int pos=0;
        for(int i=0;i<windows;++i){
            const double x=per[0].local[i][a],y=per[1].local[i][a],z=per[2].local[i][a];
            common[i][a]=std::min({x,y,z});
            if(common[i][a]>common[pos][a])pos=i;
        }
        auto& e=m.evidence[a];const int w=a==Endurance?3:1;const double span=T*widths[w];
        e.start=std::clamp(T*(pos+.5)/windows-span/2,0.,T-span);e.end=e.start+span;
        const auto [lo,hi]=ranges.slots[w][pos];
        for(int j=0;j<metrics;++j){
            int v[3];for(int k=0;k<3;++k)v[k]=per[k].counts[hi][j]-per[k].counts[lo][j];
            e.counts[j]=static_cast<int>(med(v[0],v[1],v[2]));
        }
        for(int k=0;k<3;++k)e.load[k]=per[k].local[pos][a];
    }
    summarize(common,m.summary[0]);
    const auto counts=per[0].counts.back();
    const int heads=gaugeNoteCount(c);const double total=c.total>0.?c.total:defaultGaugeTotal(heads);
    m.context={T,double(heads),total,heads/std::max(1.,total),counts[0]/T,counts[1]/T,counts[2]/T,
        counts[3]/T,counts[4]/T,counts[5]/T,counts[6]/T,double(extraPoorCents(heads,static_cast<int>(total)))/100.};
    return m;
}
}

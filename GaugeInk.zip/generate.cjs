const fs = require('node:fs');
const path = require('node:path');
const { createCanvas, loadImage } = require('@napi-rs/canvas');
const glyphs = require('./glyphs.json');
const red = [255,43,61];
const strength = percent => Math.pow(Math.max(0,(percent-50)/50), .65);
function tint(mask, rgb) {
  const result = createCanvas(mask.width, mask.height);
  const c = result.getContext('2d');
  c.drawImage(mask,0,0);
  c.globalCompositeOperation = 'source-in';
  c.fillStyle = 'rgb('+rgb.join(',')+')'; c.fillRect(0,0,result.width,result.height);
  return result;
}
function glyph(ch) {
  const [w,h,encoded] = glyphs[ch], bytes = Buffer.from(encoded,'base64');
  const tile = createCanvas(w,h), ctx = tile.getContext('2d'), image = ctx.createImageData(w,h);
  for(let i=0;i<bytes.length;i++){image.data[i*4]=image.data[i*4+1]=image.data[i*4+2]=255;image.data[i*4+3]=bytes[i];}
  ctx.putImageData(image,0,0);
  return tile;
}
function number(ctx, str, anchor, amount, fill) {
  const letters = Array.from(str, ch=>({ch,img:glyph(ch)}));
  const step = ({ch,img})=>Math.max(img.width, /\d/.test(ch)?12:ch==='.'?6:0);
  const total = letters.reduce((sum,v)=>sum+step(v),0);
  const mask = createCanvas(total+12,27), mc = mask.getContext('2d');
  let pen=6;
  // Original LOW REC. alphabet is centred in a 21 px line, then anchored at 80%.
  // The period and the p share its baseline (four source pixels of descent on p).
  for(const letter of letters) {
    const {ch,img} = letter;
    const y=ch==='.'?17-img.height:ch==='p'?17-10:Math.floor((21-img.height)/2);
    mc.drawImage(img, pen+Math.floor((step(letter)-img.width)/2),3+y);
    pen+=step(letter);
  }
  const ink = tint(mask,fill), halo = tint(mask,red);
  const value = createCanvas(mask.width,mask.height), v = value.getContext('2d');
  if(amount>0) {
    v.save();
    v.globalAlpha=amount;
    v.shadowColor='rgb(255,39,51)';v.shadowBlur=2.3;v.shadowOffsetX=.55;v.shadowOffsetY=.85;
    v.drawImage(halo,.35,.55);v.shadowColor='transparent';
    for(const [x,y] of [[-1.4,0],[1.45,0],[0,-1.35],[0,1.65],[-1,-.9],[1,-.9],[-1,1.1],[1.2,1.3]])v.drawImage(halo,x,y);
    v.restore();
  }
  v.drawImage(ink,0,0);
  const s=.8, x=anchor-(total+6)*s, y=12.5+(-1-12.5)*s;
  ctx.drawImage(value,x,y,value.width*s,value.height*s);
}
function origValue(c,atlas,pct,x,y){
  if(!pct){c.drawImage(atlas,32,24,16,24,x+247,y,16,24);return;}
  const i=pct-1;
  c.drawImage(atlas,64*(i%4),48+24*Math.floor(i/4),64,24,x+208,y,64,24);
}
function lowValue(c,atlas,pct,x=0,y=0){
  if(pct<=50){origValue(c,atlas,pct,x,y);return;}
  const k=strength(pct);
  const base=[255,Math.round(194-155*pct/100),Math.round(111-55*pct/100)];
  const ink=base.map(v=>Math.round(v*(1-k)));
  c.save();c.translate(x,y);number(c,pct+'%',264,k,ink);c.restore();
}
async function main() {
  const [original, plate] = await Promise.all(process.argv.slice(2,4).map(f=>loadImage(f)));
  const output=process.argv[4];
  const atlas = createCanvas(original.width, original.height), a = atlas.getContext('2d');
  a.drawImage(original,0,0);
  const line = createCanvas(274,24), c=line.getContext('2d');
  for(let p=51;p<=100;++p){
    const x=(p-1)%4*64,y=48+Math.floor((p-1)/4)*24;
    c.clearRect(0,0,274,24);lowValue(c,original,p);
    a.clearRect(x,y,64,24);a.drawImage(line,208,0,64,24,x,y,64,24);
  }
  fs.writeFileSync(path.join(output,'traits-80.png'),atlas.toBuffer('image/png'));
  // Both halves end at the centre of the decimal point. Fixed-width digit slots
  // keep this position identical for every amount, including numbers below 1p.
  const split=233, left=201, right=273, cell=40;
  const sheet=createCanvas(cell*10,24*21), s=sheet.getContext('2d');
  s.drawImage(plate,0,0,144,24,0,0,144,24);
  s.drawImage(plate,132,24,8,24,144,0,8,24);
  function amount(whole,frac) {
    c.clearRect(0,0,274,24);
    number(c,whole+'.'+String(frac).padStart(2,'0')+'p',264,1,[0,0,0]);
  }
  for(let i=0;i<100;++i){
    const x=(i%10)*cell,y=(Math.floor(i/10)+1)*24;
    amount(i,0);s.drawImage(line,left,0,split-left,24,x,y,split-left,24);
    amount(0,i);s.drawImage(line,split,0,right-split,24,x,y+240,right-split,24);
  }
  fs.writeFileSync(path.join(output,'hard-poor-ink.png'),sheet.toBuffer('image/png'));
  for(const pct of [0,40,50,52,74,75,76,100]){
    const frame=createCanvas(274,24), f=frame.getContext('2d');
    f.fillStyle='#121519';f.fillRect(0,0,274,24);
    f.drawImage(original,0,0,274,24,0,0,274,24);
    const end=[0,52,74,75,76].includes(pct);
    f.drawImage(original,end?0:16,24,16,24,102,0,16,24);
    lowValue(f,original,pct);
    fs.writeFileSync(path.join(output,'expected',pct+'.png'),frame.toBuffer('image/png'));
  }
  for(const cents of [0,111,667,9000]){
    const layer=createCanvas(144,24),f=layer.getContext('2d');
    f.fillStyle='#121519';f.fillRect(0,0,144,24);f.drawImage(plate,0,0,144,24,0,0,144,24);
    if(cents===0)f.drawImage(plate,132,24,8,24,127,0,8,24);
    else {f.translate(-130,0);number(f,Math.floor(cents/100)+'.'+String(cents%100).padStart(2,'0')+'p',264,1,[0,0,0]);}
    fs.writeFileSync(path.join(output,'expected','poor-'+cents+'.png'),layer.toBuffer('image/png'));
  }
}
main().catch(e=>{console.error(e);process.exitCode=1;});
